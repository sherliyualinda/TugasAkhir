<!DOCTYPE html>
<html>
<head>
	<title>Latihan Laravel Hari Ke-1</title>
</head>
<body>

<p> Ini adalah view blog. ada di route blog.</p>

</body>
</html>