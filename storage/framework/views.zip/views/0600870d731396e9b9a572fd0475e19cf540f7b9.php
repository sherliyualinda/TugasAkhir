<tr>
    <td class="header">
        
        <a href="<?php echo e(asset('/sosial-media')); ?>">
            DESAFEED
        </a>
    </td>
</tr>
