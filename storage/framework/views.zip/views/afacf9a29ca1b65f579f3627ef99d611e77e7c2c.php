<!DOCTYPE html>
<html>
<head>
	<title>Login Latihan</title>
</head>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/js/app.js')); ?>">
<body>
	<div class="container">
		<div class="card">
			<div class="card-body">
				<h1 class="text-center"> Login </h1>
					<form action="/pegawai/login_proses" method="post" class="form-horizontal">
						<?php echo e(csrf_field()); ?>

						<div class="form-group"></div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Email  : </label>
							<div class="col-sm-9">
								<input class="form-control" type="email" name="email" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="jabatan"> Password : </label>
							<div class="col-sm-9">
								<input class="form-control" type="password" name="password" required="required" minlength="8"></input>
							</div>
						</div>
						<div class="form-group" align="center">
							<input class="btn btn-submit" type="submit" value="Login"></input> &nbsp <a class="btn btn-danger" href="/pegawai/register">Register</a>
						</div>
					</form>
			<br>
			</div>
		</div>
	</div>
</body>
</html>