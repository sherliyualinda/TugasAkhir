<!DOCTYPE html>
<html>
<head>
	<title>Form Tambah Pegawai</title>
</head>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/js/app.js')); ?>">
<body>
	<div class="container">
		<div class="card">
			<div class="card-body">
				<h1 class="text-center"> Tambah Data Pegawai </h1>
					<form action="/pegawai/tambah_proses" method="post" class="form-horizontal">
						<?php echo e(csrf_field()); ?>

						<div class="form-group"></div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Nama  : </label>
							<div class="col-sm-9">
								<input class="form-control" type="text" name="pegawai_nama" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="jabatan"> Jabatan : </label>
							<div class="col-sm-9">
								<input class="form-control" type="text" name="pegawai_jabatan" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="umur"> Umur : </label>
							<div class="col-sm-9">
								<input class="form-control" type="number" name="pegawai_umur" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="alamat"> Alamat : </label>
							<div class="col-sm-9">
								<textarea class="form-control" name="pegawai_alamat" required="required"></textarea>  
							</div>
						</div>
						<div class="form-group" align="center">
							<a href="/pegawai/home">Kembali</a> &nbsp <input class="btn btn-submit" type="submit" value="Simpan Data"></input>
						</div>
					</form>
			<br>
			</div>
		</div>
	</div>
</body>
</html>