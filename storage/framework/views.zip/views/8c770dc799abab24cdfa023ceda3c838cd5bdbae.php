<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Sosial Media Desaku</title>
	<link rel="icon" href="/logo-home.png" type="image/png" sizes="16x16"> 
    
    
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('jquery-ui-1.12.1.custom/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slideshow.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/read-less-more.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/konten-detail.css')); ?>">

    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/> -->
    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/> -->

</head>
<body>
<!--<div class="se-pre-con"></div>-->
<div class="theme-layout">
	
	
	<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
		<?php echo $__env->make('theme.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</nav>
		
	<section>
		<div class="gap gray-bg">
			<div class="container-fluid">
			<?php if(Session::get('success')): ?>
			    <div class="alert alert-success">
			        <?php echo e(Session::get('success')); ?>

			        <button type="button" class="close" data-dismiss="alert">&times;</button>
			    </div>
			<?php endif; ?>
				<div class="row">
					<div class="col-lg-12">
						<div class="row" id="page-contents">
							<div class="col-lg-3">
								<aside class="sidebar static">
									<div class="widget static-widget">
										<h4 class="widget-title">Rekomendasi Desa</h4>
										<ul class="followers">
										<?php if(Auth::check()): ?>
											<?php if($rekomendasi != NULL): ?>
												<?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<figure><img src="<?php echo e(url('/data_file/'.$rek->username.'/foto_profil/'.$rek->foto_profil)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;"></figure>
														<div class="friend-meta">
															<h4><a href="/sosial-media/profil/<?php echo e($rek->username); ?>" title=""><?php echo e($rek->nama); ?></a></h4>
															<a href="/sosial-media/tambah_teman/<?php echo e($rek->username); ?>" title="" class="underline">Follow</a>
														</div>
													</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?>
												<li>
													<div align="center">Tidak Ada Rekomendasi Desa</div>
												</li>
											<?php endif; ?>
										<?php else: ?>
											<li>
												<div align="center"><a href="/sosial-media" class="underline" style="color: green; font-weight: bold;">Login</a> untuk melihat rekomendasi</div>
											</li>
										<?php endif; ?>
										</ul>
									</div><!-- who's following -->
									<div class="widget static-widget">
										<h4 class="widget-title">Rekomendasi Teman</h4>
										<ul class="followers">
										<?php if(Auth::check()): ?>
											<?php if($rekomendasi_teman != NULL): ?>
												<?php $__currentLoopData = $rekomendasi_teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rek_tmn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<figure><img src="<?php echo e(url('/data_file/'.$rek_tmn->username.'/foto_profil/'.$rek_tmn->foto_profil)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;"></figure>
														<div class="friend-meta">
															<h4><a href="/sosial-media/profil/<?php echo e($rek_tmn->username); ?>" title=""><?php echo e($rek_tmn->nama); ?></a></h4>
															<a href="/sosial-media/tambah_teman2/<?php echo e($rek_tmn->username); ?>" title="" class="underline">Tambah Teman</a>
														</div>
													</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?>
												<li>
													<div align="center">Tidak Ada Rekomendasi Teman</div>
												</li>
											<?php endif; ?>
										<?php else: ?>
											<li>
												<div align="center"><a href="/sosial-media" class="underline" style="color: green; font-weight: bold;">Login</a> untuk melihat rekomendasi</div>
											</li>
										<?php endif; ?>
										</ul>
									</div>
									<div class="widget static-widget">
										<h4 class="widget-title">Group</h4>
										<div id="searchDir2"></div>
										<ul id="people-list2" class="friendz-list" style="max-height: 200px;">
										<?php if(Auth::check()): ?>
											<?php if($list_all_group): ?>
		                                        <?php $__currentLoopData = $list_all_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<figure>
															<img src="<?php echo e(url('/data_file/group/'.$grup->nama_group.'/foto_sampul/'.$grup->foto_sampul_group)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;">
														</figure>
														<div class="friend-meta">
															<h4><a href="/sosial-media/halaman_group_detail/<?php echo e($grup->id_group); ?>" title=""><?php echo e($grup->nama_group); ?></a></h4>
														</div>
													</li>
		                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                                    <?php else: ?>
		                                    	<li>
													<div align="center">Tidak Ada Group Terdaftar</div>
												</li>
		                                    <?php endif; ?>
										<?php else: ?>
											<li>
												<div align="center"><a href="/sosial-media" class="underline" style="color: green; font-weight: bold;">Login</a> untuk melihat daftar group</div>
											</li>
										<?php endif; ?>
										</ul>
									</div><!-- who's following -->
									<div class="widget friend-list stick-widget">
										<h4 class="widget-title">Infrastruktur Desa</h4>
										<ul class="friendz-list">
										<?php if($api_infra != NULL): ?>
											<?php $__currentLoopData = $api_infra['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<figure style="width:100%; margin-bottom: 5px;">
													<img src="<?php echo e($api['foto']); ?>" alt="" style="width: 100%; height: 75px; border-radius: 0;">
												</figure>
												<div class="friendz-meta" style="padding-left: 0;">
													<a href="<?php echo e($api['url']); ?>" target="_blank"><b><?php echo e($api['nama']); ?></b></a>
													<small style="text-transform: capitalize; display: inline"><?php echo e(strtolower($api['desa'])); ?></small> <small class="<?php echo e($api['Status'] == 'nonMusrenbang' ? 'badge badge-warning' : 'badge badge-success'); ?>" style="display: inline;"><?php echo e($api['Status']); ?></small>
												</div>
											</li>
											<?php if($loop->iteration == 3): ?>
											<?php break; ?>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
										<?php else: ?>
											<li>
												<div align="center">Tidak Ada Video Terbaru</div>
											</li>
										<?php endif; ?>
										</ul>
									</div>
								</aside>
							</div><!-- sidebar -->
							<br>
							<div class="col-lg-6">
								<div>
									<?php if(isset($konten)): ?>
										<?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="central-meta item">
											<div class="user-post">
												<div class="friend-info">
													<figure>
														<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_profil/'.$data->foto_profil)); ?>" alt="" style="width: 45px; height: 45px;">
													</figure>
													<div class="friend-name">
														<ins>
															<a href="/sosial-media/profil/<?php echo e($data->username); ?>" title="">
																<?php echo e($data->username); ?>

															</a>
														</ins>
														<span style="color: black;"><a href="/sosial-media/explore/<?php echo e($data->tempat); ?>"><?php echo e($data->tempat); ?></a></span>
														<div class="d-flex justify-content-end">
														<?php if(Auth::check()): ?>
														<?php $tgl = date_format(date_create($data->created_at), "d-m-Y"); ?>
															<?php if(($data->username) != auth()->user()->pengguna->username): ?>
																<a onclick="modalMore('<?php echo e($data->id_konten); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->slug); ?>', '<?php echo e($data->foto_profil); ?>')" style="cursor: pointer;"><i class="fa fa-ellipsis-v"></i></a>
															<?php else: ?>
																<a onclick="modalMore2('<?php echo e($data->id_konten); ?>', '<?php echo e($data->foto_profil); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->tempat); ?>', '<?php echo e($data->foto_video_konten); ?>', '<?php echo e($data->caption); ?>', '<?php echo e($tgl); ?>', '<?php echo e($data->slug); ?>')" style="cursor: pointer;"><i class="fa fa-ellipsis-v"></i></a>
															<?php endif; ?>
														<?php endif; ?>
														</div>
													</div>
													<div class="post-meta">
														<div class="align-self-center single-item">
														<?php $media = explode(", ", $data->foto_video_konten); ?>
														<?php $tgl = date_format(date_create($data->created_at),"d-m-Y"); ?>
														<?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media_konten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<?php if(strpos($media_konten, '.mp4')): ?>
																<video width="100%" height="100%" autoplay loop muted>
																  	<source src="<?php echo e(url('/data_file/'.$data->username.'/foto_konten/'.$tgl.'/'.$data->slug.'/'.$media_konten)); ?>" type="video/mp4">
																  	<source src="<?php echo e(url('/data_file/'.$data->username.'/foto_konten/'.$tgl.'/'.$data->slug.'/'.$media_konten)); ?>" type="video/ogg">
																  	Your browser does not support the video tag.
																</video>
															<?php else: ?>
																<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_konten/'.$tgl.'/'.$data->slug.'/'.$media_konten)); ?>" alt="">
															<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
														<div class="we-video-info" style="padding-top: 0; padding-bottom: 0;">
															<ul style="max-height: 30px;">
																<?php if(Auth::check()): ?>
																<li data-id="<?php echo e($data->id_konten); ?>" data-is-like="<?php echo e($data->is_like ? 1 : 0); ?>" class="action-like-or-dislike" style="margin-right: 5px;height: 23px;">
																	<span class="like" data-toggle="tooltip" title="<?php echo e($data->is_like ? 'Batal Menyukai' : 'Menyukai'); ?>">
																		<div class="menu" style="width: 23px; height: 23px;">
																			<div class="btn trigger" style="background: none;">
																				<i id="icon_like<?php echo e($data->id_konten); ?>" class="<?php echo e($data->is_like ? 'fa fa-heart' : 'fa fa-heart-o'); ?>" style="font-size: 20px;color: black;"></i>
																			</div>
																		</div>
																	</span>
																</li>
																<li class="social-media" style="margin-right: 5px; height: 23px; position: absolute;">
																	<span class="like">
																		<div class="menu" style="width: 23px; height: 23px;">
																			<div class="btn trigger" style="background: none;">
																				<i class="fa fa-share-alt" style="color: black; font-size: 20px;"></i>
																			</div>
																			<?php

																				$url = urlencode("http://127.0.0.1:8000/sosial-media/p/".$data->slug);
																				$media = explode(", ", $data->foto_video_konten); $i=1;
																				foreach ($media as $media_konten){
																					$img = urlencode(url('/data_file/'.$media_konten));
																					if($loop->iteration == 1){
																						break;
																					}
																				}
																				$title = $data->username;
																				$summary = $data->caption;

																				// $url=urlencode("http://www.fbchandra.com/developers/share-page-on-facebook");

																				// $img=urlencode("http://www.fbchandra.com/media/developers/share-page.jpg");

																				// $title=urlencode("Share your link on facebook");

																				// $summary="Share your link on facebook using sharer.php. You can choose your custom title, image and summary to share content on facebook timeline.";

																			?>
																			<div class="rotater">
																				<div class="btn btn-icon"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>&display=popup" target="_blank" title=""><i class="fa fa-facebook"></i></a></div>
																			</div>
																			<!-- <div class="rotater">
																				<div class="btn btn-icon"><a href="http://www.facebook.com/sharer/sharer.php?s=100&p[url]=<?php echo $url ?>&p[images][0]=<?php echo $img ?>&p[title]=<?php echo $title ?>&p[summary]=<?php echo $summary ?>" target="_blank" title=""><i class="fa fa-facebook"></i></a></div>
																			</div> -->
																			<div class="rotater">
																				<div class="btn btn-icon"><a href="https://twitter.com/intent/tweet?url=<?php echo e($url); ?>" target="_blank" title=""><i class="fa fa-twitter"></i></a></div>
																			</div>
																			<div class="rotater">
																				<div class="btn btn-icon"><a href="whatsapp://send?text=<?php echo e($url); ?>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" title=""><i class="fa fa-whatsapp"></i></a>
																				</div>
																			</div>
																		</div>
																	</span>
																</li>
																<?php endif; ?>
															</ul>
														</div>
														<?php if(Auth::check()): ?>
															<?php if($likes): ?>
																<?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<?php if($like->id_konten == $data->id_konten): ?>
																		<p style="margin-bottom: 0px;">Disukai oleh <a href="/sosial-media/profil/<?php echo e($like->username); ?>"><b><?php echo e($like->username); ?></b></a> dan<span style="cursor: pointer" data-toggle="modal" data-target="#modalLike<?php echo e($data->id_konten); ?>"> <b>lainnya</b></span></p>
																		<?php if(COUNT($like->username) == 1): ?>
																		<?php break; ?>
																		<?php endif; ?>
																	<?php endif; ?>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
														<?php endif; ?>
														<div class="description" style="margin-top: 0;">
															<p style="margin-bottom: 0px;"> 
																<strong><?php echo e($data->username); ?></strong> <span class="addReadMore showlesscontent"> <?php echo e($data->caption); ?> </span>
															</p>
															<span style="color: #999; float: left;font-size: 12px;text-transform: capitalize;width: 100%;">
																<?php echo date_format(date_create($data->created_at), "d M Y H:i A"); ?>
															</span>
														</div>
													</div>
												</div>
												<div class="modal fade" id="modalLike<?php echo e($data->id_konten); ?>" role="dialog">
												    <div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 400px;">
												      	<div class="modal-content">
													        <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
													          	<h6 class="modal-title">Menyukai</h6>
													        </div>
												        	<ul class="friendz-list list-group list-group-flush" style="overflow-y: auto!important; max-height: 250px;">
													        	<?php if($likes_all != NULL): ?>
																	<?php $__currentLoopData = $likes_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<?php if($data2->id_konten == $data->id_konten): ?>
																			<div class="list-group list-group-flush" style="max-height: 315px;">
																	        	<a href="#" class="list-group-item list-group-item-action" data-dismiss="modal" style="padding-left: 10px; padding-right: 10px;">
																	        		<div class="media">
																						<img src="<?php echo e(url('/data_file/'.$data2->username.'/foto_profil/'.$data2->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
																					  	<div class="media-body align-self-center">
																					  		<small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data2->username); ?></small><br>
																					    	<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data2->nama); ?></small>
																					  	</div>
																					</div>
																	        	</a>
																	        </div>
																	    <?php endif; ?>
													        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																<?php endif; ?>
												        	</ul>
												      	</div>
												    </div>
												</div>
												<div class="coment-area">
													<ul class="we-comet list-cmt<?php echo e($data->id_konten); ?>" style="overflow-y: auto; max-height: 200px;">
														<?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<?php if(isset($dataa->isi_komentar)): ?>
																<?php if(($data->id_konten == $dataa->id_konten) && $dataa->id_balas_komen == 0): ?>
																	<li id="comment_<?php echo e($dataa->id_cmt); ?>" class="list-rep_cmt_<?php echo e($dataa->id_cmt); ?>">
																		<div id="li-cmt-<?php echo e($dataa->id_cmt); ?>">
																			<div class="comet-avatar">
																				<img src="<?php echo e(url('/data_file/'.$dataa->username.'/foto_profil/'.$dataa->foto_profil)); ?>" alt="" style="height: 45px; width: 45px;">
																			</div>
																			<div class="we-comment">
																				<div class="coment-head">
																					<h5 style="text-transform: none;"><a href="/sosial-media/profil/<?php echo e($dataa->username); ?>" title=""><?php echo e($dataa->username); ?></a></h5>
																					<span><?php echo e(date_format(date_create($dataa->tanggal_komen), "d M Y H:i A")); ?></span>
																					<!-- <a class="we-reply" href="#" title="Reply"><i class="fa fa-reply"></i></a> -->
																					
																					<?php if(Auth::check()): ?>
																					<?php if((Auth::user()->pengguna->username == $dataa->username) OR (Auth::user()->pengguna->username == $data->username)): ?>
																					<a onclick="modalHapusKomentar('<?php echo e($dataa->id_cmt); ?>')" style="cursor: pointer"><i class="ti-trash hide" style="color: red;"></i></a>
																					<?php endif; ?>
																					<?php if(Auth::user()->pengguna->username != $dataa->username): ?>
																					<a onclick="modalReportKomentar('<?php echo e($dataa->id_cmt); ?>')" style="cursor: pointer"><i class="ti-info-alt hide" style="color: red;"></i></a>
																					<?php endif; ?>
																					<button class="we-reply btn btn-link" style="font-size: 12px; font-weight: 500; float: right;position: relative;top: 0;" onclick="balas_komen('<?php echo e('@'.$dataa->username); ?>', '<?php echo e($dataa->id_cmt); ?>', '<?php echo e($dataa->username); ?>', '<?php echo e($data->id_konten); ?>')" value="<?php echo e($dataa->id_cmt); ?>">Balas</button>
																					<?php endif; ?>
																				</div>
																				<p style="margin-top: 0px;"><?php echo e($dataa->isi_komentar); ?></p>
																			</div>
																		</div>
																		<?php $id_cmt_parent = $dataa->id_cmt; ?>
																		<?php $__currentLoopData = $balas_komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balas_komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<?php if($balas_komen->id_balas_komen != 0): ?>
																		<?php if($dataa->id_cmt == $balas_komen->id_balas_komen): ?>
																		<div id="li-cmt-<?php echo e($balas_komen->id_cmt); ?>">
																			<ul id="comment_<?php echo e($balas_komen->id_cmt); ?>">
																				<li>
																					<div class="comet-avatar">
																						<img src="<?php echo e(url('/data_file/'.$balas_komen->username.'/foto_profil/'.$balas_komen->foto_profil)); ?>" alt="" style="height: 35px; width: 35px;">
																					</div>
																					<div class="we-comment">
																						<div class="coment-head">
																							<h5 style="text-transform: none;"><a href="/sosial-media/profil/<?php echo e($balas_komen->username); ?>" title=""><?php echo e($balas_komen->username); ?></a></h5>
																							<span><?php echo e(date_format(date_create($balas_komen->tanggal_komen), "d M Y H:i A")); ?></span>
																							
																							<?php if(Auth::check()): ?>
																							<?php if((Auth::user()->pengguna->username == $balas_komen->username) OR (Auth::user()->pengguna->username == $data->username)): ?>
																							<a onclick="modalHapusKomentar('<?php echo e($balas_komen->id_cmt); ?>')" style="cursor: pointer"><i class="ti-trash hide" style="color:red;"></i></a>
																							<?php endif; ?>
																							<?php if(Auth::user()->pengguna->username != $balas_komen->username): ?>
																							<a onclick="modalReportKomentar('<?php echo e($balas_komen->id_cmt); ?>')" style="cursor: pointer"><i class="ti-info-alt hide" style="color: red;"></i></a>
																							<?php endif; ?>
																							<button class="we-reply btn btn-link" style="font-size: 12px; font-weight: 500; float: right;position: relative;top: 0;" onclick="balas_komen('<?php echo e('@'.$balas_komen->username); ?>', '<?php echo e($id_cmt_parent); ?>', '<?php echo e($balas_komen->username); ?>','<?php echo e($data->id_konten); ?>')" value="<?php echo e($balas_komen->id_cmt); ?>">Balas</button>
																							<?php endif; ?>
																						</div>
																						<p style="margin-top: 0px;"><?php echo  html_entity_decode($balas_komen->isi_komentar) ?></p>
																					</div>
																				</li>
																			</ul>
																		</div>
																		<?php endif; ?>
																		<?php endif; ?>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	</li>
																	
																	<!-- <li>
																		<a href="#" title="" class="showmore underline">more comments</a>
																	</li> -->
																<?php endif; ?>
															<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
													<ul class="we-comet">
														<li class="post-comment">
															<?php if(Auth::check()): ?>
																<div class="comet-avatar">
																	<img src="<?php echo e(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil)); ?>" alt="" style="width: 35px; height: 35px;">
																</div>
																<div class="post-comt-box2"> <!-- post-comt-box -->
																	<form method="post" action="/sosial-media/post_komen" enctype="multipart/form-data">
																	<?php echo e(csrf_field()); ?>

																		<input type="hidden" name="id_konten" value="<?php echo e($data->id_konten); ?>" class="konten_<?php echo e($data->id_konten); ?>">
																		<span class="thumb-xs<?php echo e($data->id_konten); ?>">
																			<textarea placeholder="Post your comment" name="isi_komentar" style="width: 90%;" class="txt_comment_<?php echo e($data->id_konten); ?>"></textarea>
																		</span>
																		
																		<button type="button" onclick="uploadKomen('<?php echo e($data->id_konten); ?>')" class="btn btn-submit" style="border-radius: 3px;">Post</button>
																	</form>	
																</div>
															<?php else: ?>
																<a href="/sosial-media" class="underline" style="color: green; font-weight: bold;">Login</a> untuk membuat komentar.
															<?php endif; ?>
														</li>
													</ul>
												</div>
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</div>
							</div><!-- centerl meta -->
							<div class="col-lg-3">
								<aside class="sidebar static">
									<?php if(Auth::check()): ?>
										<?php if(auth()->user()->pengguna->jenis_akun == 'desa'): ?>
										<div class="widget">
											<h4 class="widget-title">Your page</h4>	
											<div class="your-page">
												<figure>
													<img src="<?php echo e(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil)); ?>" style="width: 50px; height: 50px;">
												</figure>
												<div class="page-meta">
													<a href="/sosial-media/profil/<?php echo e(auth()->user()->pengguna->username); ?>" title="" class="underline">My page</a>
													<span>
														<i class="ti-user" style="vertical-align: unset"></i>
														<?php $__currentLoopData = $jml_konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jml): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<a href="insight.html" title="">Post <em><?php echo e($jml->jml_konten); ?></em></a>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</span>
													<!-- <span><i class="ti-user"></i><a href="insight.html" title="">Following <em>2</em></a></span> -->
												</div>
												<div class="page-likes">
													<ul class="nav nav-tabs likes-btn">
														<li class="nav-item"><a class="active" href="#link1" data-toggle="tab">likes</a></li>
														<li class="nav-item"><a class="" href="#link2" data-toggle="tab">Followers</a></li>
													</ul>
													<!-- Tab panes -->
													<div class="tab-content">
														<div class="tab-pane active fade show " id="link1" >
															<?php $__currentLoopData = $data_likes_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_likes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span><i class="ti-heart"></i><?php echo e(number_format($dt_likes->jml_likes)); ?></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php $__currentLoopData = $data_likes_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_likes_week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<?php if($dt_likes_week->jml_likes !== 0): ?>
																	<a href="#" title="weekly-likes"><?php echo e(number_format($dt_likes_week->jml_likes)); ?> like baru minggu ini</a>
																<?php endif; ?>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
														<div class="tab-pane fade" id="link2" >
															<?php $__currentLoopData = $data_followers_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_followers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span><i class="ti-user"></i><?php echo e(number_format($dt_followers->jml)); ?></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php $__currentLoopData = $data_followers_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_followers_week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<?php if($dt_followers_week->jml !== 0): ?>
																	<a href="#" title="weekly-likes"><?php echo e(number_format($dt_followers_week->jml)); ?> Followers Baru Minggu Ini</a>
																<?php endif; ?>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
													</div>
												</div>
											</div>
										</div><!-- page like widget -->
										<?php endif; ?>
									<?php endif; ?>
									<!-- <div class="widget friend-list stick-widget"> -->
									<div class="widget friend-list">
										<h4 class="widget-title">Berita Terbaru</h4>
										<ul class="friendz-list">
										<?php if($api_berita != NULL): ?>
											<?php $__currentLoopData = $api_berita['articles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li>
													<figure style="width:100%; margin-bottom: 5px;">
														<img src="<?php echo e($api['urlToImage']); ?>" alt="" style="width: 100%; height: 75px; border-radius: 0;">
													</figure>
													<div class="friendz-meta" style="padding-left: 0;">
														<a href="<?php echo e($api['url']); ?> "><b><?php echo e($api['title']); ?></b></a>
														<small style="text-transform: capitalize;"><?php echo e(strtolower($api['source']['name'])); ?> - <?php echo e(date_format(date_create($api['publishedAt']), "d M 'y")); ?></small>
													</div>
												</li>
												<?php if($loop->iteration == 3): ?>
												<?php break; ?>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
											<li>
												<div align="center">Tidak Ada Berita Terbaru</div>
											</li>
										<?php endif; ?>
										</ul>
									</div>
									<div class="widget friend-list stick-widget">
										<h4 class="widget-title">Video Terbaru</h4>
										<ul class="friendz-list">
										<?php if($api_video != NULL): ?>
											<?php $__currentLoopData = $api_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<figure style="width:100%; margin-bottom: 5px;">
													<img src="https://desatube.masuk.web.id<?php echo e($api['thumbnail']); ?>" alt="" style="width: 100%; height: 75px; border-radius: 0;">
												</figure>
												<div class="friendz-meta" style="padding-left: 0;">
													<a href="https://desatube.masuk.web.id/watch/<?php echo e($api['uid']); ?>" target="_blank"><b><?php echo e($api['title']); ?></b></a>
													<small style="text-transform: capitalize;"><?php echo e(strtolower($api['village_name'])); ?> - <?php echo e(date_format(date_create($api['created_at']), "d M 'y")); ?></small>
												</div>
											</li>
											<?php if($loop->iteration == 3): ?>
											<?php break; ?>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
										<?php else: ?>
											<li>
												<div align="center">Tidak Ada Video Terbaru</div>
											</li>
										<?php endif; ?>
										</ul>
									</div><!-- friends list sidebar -->
								</aside>
							</div><!-- sidebar -->
						</div>	
					</div>
				</div>
			</div>
		</div>	
	</section>

</div>

<div class="modal fade" id="myModalEdit" role="dialog">
    <div class="modal-dialog" style="max-width: 600px;">
        <form method="post" action="/sosial-media/edit_konten_proses" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Konten</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="closebtn" value="">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="text-align: center;">
                    <div class="friend-info" style="text-align: left; margin-bottom: 15px;">
                        <figure style="width: 10%;">
                            <img id="foto_post" src="" alt="" style="width: 45px; height: 45px; border-radius: 50%;">
                        </figure>
                        <div class="friend-name" style="width:85%; padding-left: 0px;">
                            <ins>
                                <a id="uname" href="" title=""></a>
                            </ins>
                            <span id="tmpt" style="color: black;"></span>
                        </div>
                    </div>
                    <div class="wrap-modal-slider">
                        <div class="slideshow-container editSlide">
                            <div id="media_post"></div>
                            <a class="prev" onclick="" id="prevClick">&#10094;</a>
                            <a class="next" onclick="" id="nextClick">&#10095;</a>
                        </div>
                    </div>
					<div class="newpst-input" style="margin-top: 15px;">
						<input type="hidden" name="id_konten" id="hidden_id" value=""></input>
						<textarea rows="3" name="caption" id="capt" style="border: 1px solid #eeeeee; border-radius: 0; border-bottom: 0;" onkeyup="countCharsEdit(this);" maxlenght="500"></textarea>
						<div class="attachments">
                            <ul>
                                <li><small id="charNumEdit" style="margin:0;"></small></li>
                            </ul>
                        </div>
					</div>
                </div>
                <div class="modal-footer">
                    <input class="btn btn-sm btn-submit" type="submit" style="background-color: #358f66; color: white;" value="Update"></input>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if(Auth::check()): ?>
<div class="modal fade" id="modalShare" role="dialog">
    <div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 400px;">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
                <h6 class="modal-title">Bagikan</h6>
            </div>
            <div class="input-group flex-nowrap searchKey" id="cari_teman_2">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
                        Ke: 
                    </span>
                </div>
                <div id="kolom_input_cari_2" class="kolom_cari" style="width: 100%;"></div>
            </div>
            <form method="post" action="/sosial-media/share_post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

                <ul class="friendz-list list-group list-group-flush findFr" style="margin-top: 0px; overflow-y: auto!important; max-height: 250px;" id="teman_yang_dicari_2">
                    <?php if($teman != NULL): ?> 
                        <?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group list-group-flush" style="max-height: 315px;">
                            <a class="list-group-item list-group-item-action" style="padding-right: 10px; padding-left: 10px;">
                                <div class="input-group mb-3" style="margin-bottom: 0px!important;">
                                    <div class="media">
                                        <img src="<?php echo e(url('/data_file/'.$data2->username.'/foto_profil/'.$data2->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
                                        <div class="media-body align-self-center">
                                            <small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data2->username); ?></small><br>
                                            <small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data2->nama); ?></small>
                                        </div>
                                    </div>
                                    <div class="input-group-append" style="position: absolute;right: 0;top: 35%;">
                                        <input type="checkbox" name="pilih_teman[]" value="<?php echo e($data2->id_pengguna); ?>" aria-label="Checkbox for following text input">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php else: ?>
                        <li>
                            <div align="center">Tidak ada teman</div>
                        </li>
                    <?php endif; ?>
                </ul>
                <input type="hidden" name="id_konten" id="hidden_id_share" value=""></input>
                <div class="modal-footer" style="padding: 8px;">
                    <input class="btn btn-sm btn-submit" type="submit" style="background-color: #358f66; color: white;" value="Submit"></input> 
                </div>
            </form>
        </div>
    </div>
</div>	

<div class="modal fade" id="modalReport" role="dialog">
    <div class="modal-dialog modal-sm" style="max-width: 600px;">
        <form method="post" action="/sosial-media/report_proses" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Report <span class="kategori_report"></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Alasan Pelaporan <span class="kategori_report"></span></label>
                        <select class="form-control" id="alasan_report" name="alasan_report">
                            <option selected disabled>Pilih Alasan</option>
                            <option value="Spam">Spam</option>
                            <option value="Ujaran / Simbol Kebencian">Ujaran / Simbol Kebencian</option>
                            <option value="Ketelanjangan / Aktivitas Seksual">Ketelanjangan / Aktivitas Seksual</option>
                            <option value="Kekerasan / Organisasi Berbahaya">Kekerasan / Organisasi Berbahaya</option>
                            <option value="Penipuan">Penipuan</option>
                            <option value="Informasi Palsu">Informasi Palsu</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="kategori" name="kategori_report" value=""/>
                    <input type="hidden" name="acct_reporter" value="<?php echo e(Auth::user()->pengguna->id_pengguna); ?>"/>
                    <input type="hidden" id="reported" name="id_reported" value=""/>
                    <input class="btn btn-sm btn-submit" type="submit" style="background-color: red; color: white;" value="Report"></input>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/script.js')); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slideshow.js')); ?>"></script>
<script src="<?php echo e(asset('js/read-less-more.js')); ?>"></script>
<!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script> -->
<!-- <script type="text/javascript" src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script> -->
<script type="text/javascript" src="<?php echo e(asset('slick-1.8.1/slick/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/konten-detail.js')); ?>"></script>

<!-- Script --><!-- 
<script src="<?php echo e(asset('js/jquery-2.1.4.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>" type="text/javascript"></script> -->
<script type="text/javascript">

    // CSRF Token
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function(){

      $( "#search" ).autocomplete({
      	appendTo: "#container_search",
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url:"<?php echo e(route('sosial-media.cari_pengguna')); ?>",
            type: 'post',
            dataType: "json",
            data: {
               _token: CSRF_TOKEN,
               search: request.term
            },
            success: function( data ) {
               response( data );
            }
          });
        },
        select: function (event, ui) {
           let username = ui.item.value;
           window.location.href = window.location.origin+"/sosial-media/profil/"+username;
           return false;
        }
      })
      .data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	      return $( "<li>" )
	        .append( "<div class='media'><img src='"+item.icon+"' class='align-self-center mr-3' alt='...' style='width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;'> <div class='media-body align-self-center'> <small style='font-weight: 700; color: black; margin-bottom: 0rem;'>"+item.value+"</small><br><small class='mt-0' style='margin-bottom: 0rem; font-weight: 500; color: #989e99;'>"+item.label+"</small>")
	        .appendTo( ul );
	  };

    });

	// var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
	// $('#notif').click(function () {
	// 	$.ajax({
	// 		url: "<?php echo e(route('sosial-media.update_notif')); ?>",
	// 		type: 'post',
	// 		// dataType: "json",
	// 		data: {
	// 			_token: CSRF_TOKEN
	// 		},
	// 		success: function (data) {
	// 			if (document.getElementById("jml_notif")) {
	// 				document.getElementById("jml_notif").style.visibility = "hidden";
	// 			}
	// 		}
	// 	});
	// });
</script>
</body>	

</html>