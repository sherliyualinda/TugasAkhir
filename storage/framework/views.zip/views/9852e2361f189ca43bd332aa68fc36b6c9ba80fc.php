<section>
	<div class="gap100" style="padding: 20px 0;">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="shop-page">
						<div class="row">
						<?php if($api_product != NULL): ?>
							<?php $__currentLoopData = $api_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-4">
									<div class="product-box">
										<figure>
											<span class="new">New</span>
											<?php $x=1; ?>
											<?php if($api['galleries']): ?>
												<?php $__currentLoopData = $api['galleries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api_gbr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<img src="http://marketpalcedesaku.masuk.web.id/storage/<?php echo e($api_gbr['photos']); ?>" style="height: 261px; widht: 261px; object-fit: cover;" alt="">
													<?php if($loop->iteration == 1): ?>
													<?php break; ?>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?>
												<img src="http://marketpalcedesaku.masuk.web.id/storage/<?php echo e($api['category']['photo']); ?>" style="height: 261px; widht: 261px; object-fit: cover;" alt="">
											<?php endif; ?>
										</figure>
										<div class="product-name" style="padding-bottom: 5px; text-align: left">
											<h5><a href="#" title=""><?php echo e($api['name']); ?></a></h5>
											<div class="prices">
												<ins>Rp<?php echo e(number_format($api['price'])); ?></ins>
											</div>
										</div>
										<a href="http://marketpalcedesaku.masuk.web.id/details/<?php echo e($api['slug']); ?>" target="_blank">
											<button type="button" class="btn btn-sm btn-warning btn-block" style="position: relative; float: left; font-weight: bold; color: white;padding-bottom: 1px; padding-top: 1px; border-radius: 0;">Lihat</button>
										</a>
									</div>
								</div>
								<?php if($loop->iteration == 6): ?>
								<?php break; ?>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						<?php else: ?>
							<div class="col-lg" style="padding-bottom:15px;">
								<strong style="font-size: 16px;">Belum Ada Produk</strong>
							</div>
						<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>