<!DOCTYPE html>
<html>
<head>
	<title>Register Latihan</title>
</head>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/js/app.js')); ?>">
<!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/js/jquery-3.2.0.min.js')); ?>"> -->
<body>
	<div class="container">
		<div class="card">
			<div class="card-body">
				<h1 class="text-center"> Register </h1>
					<form action="/pegawai/register_proses" method="post" class="form-horizontal">
						<?php echo e(csrf_field()); ?>

						<div class="form-group"></div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Nama  : </label>
							<div class="col-sm-9">
								<input class="form-control" type="text" name="name" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Email  : </label>
							<div class="col-sm-9">
								<input class="form-control" type="email" name="email" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="jabatan"> Password : </label>
							<div class="col-sm-9">
								<input class="form-control" type="password" name="password" required="required" minlength="8"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="jabatan"> Konfirmasi Password : </label>
							<div class="col-sm-9">
								<input class="form-control" type="password" name="konf_password" required="required"></input>
							</div>
						</div>
						<div class="form-group" align="center">
							<a href="/pegawai">Kembali</a> &nbsp <input class="btn btn-submit" type="submit" value="Register"></input> 
						</div>
					</form>
			<br>
			</div>
		</div>
	</div>
</body>
</html>