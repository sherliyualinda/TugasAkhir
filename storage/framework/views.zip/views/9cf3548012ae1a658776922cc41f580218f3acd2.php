<!DOCTYPE html>
<html>
<head>
	<title>Upload Foto</title>
</head>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/js/app.js')); ?>">
<body>
	<div class="container">
		<div class="card">
			<div class="card-body">
				<h1 class="text-center"> Upload Foto </h1>
					<form method="post" action="/upload/upload_proses" class="form-horizontal" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<div class="form-group"></div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="upload"> Upload Foto: </label>
							<div class="col-sm-9">
								<input class="form-control" type="file" name="file" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="upload"> Keterangan: </label>
							<div class="col-sm-9">
								<input class="form-control" type="textarea" name="keterangan" required="required"></input>
							</div>
						</div>
						<div class="form-group" align="center">
							<a href="/pegawai">Kembali</a> &nbsp <input class="btn btn-submit" type="submit" value="Simpan Data"></input>
						</div>
					</form>
				<br>
				<br>
				<h2 class="text-center">Data Foto</h2>
					<table class="table table-bordered table-striped table-hover" border="1">
						<thead>
							<tr>
								<th width="1%"><center>File</center></th>
								<th><center>Keterangan</center></th>
								<th width="1%"><center>Opsi</center></th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><img width="200px" src="<?php echo e(url('/data_file/'.$f->file)); ?>"></td>
								<td><?php echo e($f->keterangan); ?></td>
								<td><a class="btn btn-danger" href="/upload/hapus_file/<?php echo e($f->id); ?>">Hapus</a></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

					<p>Halaman : <?php echo e($file->currentPage()); ?><br>
					Jumlah Data : <?php echo e($file->total()); ?><br>
					Data Per Halaman : <?php echo e($file->perPage()); ?></p>

					<ul class="pagination"><?php echo e($file->links()); ?></ul>
			</div>
		</div>
	</div>
</body>
</html>