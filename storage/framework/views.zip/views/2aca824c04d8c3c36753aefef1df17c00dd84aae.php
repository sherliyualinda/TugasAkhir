<!-- <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light"> -->
	<div class="logo col-lg-2">
		<a title="" href="<?php echo e(asset('/sosial-media/beranda')); ?>">
			<img src="/desafeed-logo.png" alt="" style="max-height: 50px;">
		</a>
	</div>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto col-lg-2">
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle menu-text" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: black;">
				Produk Desaku
				</a>
				<div class="dropdown-menu box-size" aria-labelledby="navbarDropdown" style="width: 700px;">
					<div class="row" style="margin-right: 0; margin-left: 0;">
						<div class="col desa-col">
							<a class="dropdown-item" target="_blank" href="http://marketpalcedesaku.masuk.web.id/">
								<img src="/desanews-logo.png" style="min-width: 150px;">
								<br>
								<small style="white-space: normal!important;">Tempat baca berita desa terkini & terupdate!</small>
							</a>
						</div>
						<div class="col desa-col">
							<a class="dropdown-item" target="_blank" href="http://marketpalcedesaku.masuk.web.id/">
								<img src="/desatour-logo.png" style="min-width: 150px;">
								<br>
								<small style="white-space: normal!important;">Jelajahi wisata, kuliner, dan penginapan desa!</small>
							</a>
						</div>
						<div class="col desa-col">
							<a class="dropdown-item" target="_blank" href="http://marketpalcedesaku.masuk.web.id/">
								<img src="/desacuss-logo.png" style="min-width: 150px;">
								<br>
								<small style="white-space: normal!important;">Diskusikan rencana program desa disini!</small>
							</a>
						</div>
					</div>
					<div class="row" style="margin-right: 0; margin-left: 0;">
						<div class="col desa-col">
							<a class="dropdown-item" target="_blank" href="http://marketpalcedesaku.masuk.web.id/">
								<img src="/desatube-logo.png" style="min-width: 150px;">
								<br>
								<small style="white-space: normal!important;">Publish video desa disini!</small>
							</a>
						</div>
						<div class="col desa-col">
							<a class="dropdown-item" target="_blank" href="http://marketpalcedesaku.masuk.web.id/">
								<img src="/desastore-logo.png" style="min-width: 150px;">
								<br>
								<small style="white-space: normal!important;">Jual & beli produk desa disini!</small>
							</a>
						</div>
						<div class="col desa-col"></div>
					</div>
				</div>
			</li>
		</ul>
		<?php if(Auth::check()): ?>
			<div class="col-lg-6 d-flex justify-content-center box-search">
				<form class="form-inline my-lg-0">
					<div id="container_search" style="display: block; position:relative">
						<input class="form-control mr-sm-2" type="search" id="search" name="search" placeholder="Search" aria-label="Search">
						<input type="hidden" name="searchUname"></input>
					</div>
				</form>
			</div>
		<?php endif; ?>
		<ul class="navbar-nav col-lg-4 d-flex justify-content-end">
			
			<?php if(Auth::check()): ?>
				<li class="nav-item active">
					<a class="nav-link beranda" href="/sosial-media/beranda" title="Home" data-ripple=""><i class="ti-home" style="color:black;"></i></a>
					<!-- <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a> -->
				</li>
				<li class="nav-item">
					<a class="nav-link notif" title="Notification" id="notif" data-ripple="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<i class="ti-bell" style="color:black;"></i>
						<?php if($total_notif != 0): ?>
							<span class="badge badge-danger" id="jml_notif"><?php echo e($total_notif); ?></span>
						<?php endif; ?>
					</a>
					<div class="dropdown-menu dropdown-menu-right" style="min-width: 100%">
						<h6 style="text-align: center">Notifikasi</h6>
						<hr style="margin-top: 0.25rem; margin-bottom: 0.25rem;">
						<div class="a" style="overflow-y: auto; max-height: 250px;">
						<?php if(sizeof($list_notif_display) > 0): ?>
							<?php $__currentLoopData = $list_notif_display; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($list->jenis_notif == 'Menyukai'): ?>
									<button class="dropdown-item" type="button" onclick="location.href='/sosial-media/konten_detail/<?php echo e($list->id_konten_likes); ?>';">
										<div class="media">
											<img src="<?php echo e((url('/data_file/'.$list->username_likers.'/foto_profil/'.$list->foto_profil_likers))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
											<div class="media-body align-self-center" style="white-space: initial; width:200px;">
												<small style="color: black"><b><?php echo e($list->username_likers); ?></b> 
												menyukai postingan anda
												</small>
												<small style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_like), "d M Y H:i A")); ?></small>
											</div>
											<?php $media = explode(", ", $list->foto_video_konten); ?>
											<?php $tgl = date_format(date_create($list->tgl_konten),"d-m-Y"); ?>
											<?php for($x = 0; $x < 1; $x++): ?>
												<?php if(strpos($media[$x], '.mp4')): ?>
													<video width="40" height="40" style="object-fit:none; margin-left: 16px;">
														<source src="<?php echo e(url('/data_file/'.$list->username_konten.'/foto_konten/'.$tgl.'/'.$list->slugg.'/'.$media[$x])); ?>" type="video/mp4">
														<source src="<?php echo e(url('/data_file/'.$list->username_konten.'/foto_konten/'.$tgl.'/'.$list->slugg.'/'.$media[$x])); ?>" type="video/ogg">
														Your browser does not support the video tag.
													</video>
												<?php else: ?>
													<img src="<?php echo e(url('/data_file/'.$list->username_konten.'/foto_konten/'.$tgl.'/'.$list->slugg.'/'.$media[$x])); ?>" class="align-self-center ml-3" style="width: 40px; height: 40px; border-radius: 0%;">
												<?php endif; ?>
											<?php endfor; ?>
										</div>
									</button>
								<?php elseif($list->jenis_notif == 'Komentar'): ?>
									<button class="dropdown-item" type="button" onclick="location.href='/sosial-media/konten_detail/<?php echo e($list->id_konten_komen); ?>';">
										<div class="media">
											<img src="<?php echo e((url('/data_file/'.$list->username_commentor.'/foto_profil/'.$list->foto_profil_commentor))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
											<div class="media-body align-self-center" style="white-space: initial; width:200px;">
												<small style="color: black"><b><?php echo e($list->username_commentor); ?></b> 
												<?php if(strpos($list->isi_komentar, auth()->user()->pengguna->username) !== false): ?>
													menyebut anda dalam komentar: 
												<?php else: ?> 
													mengomentari postingan anda:
												<?php endif; ?>
												<?php echo html_entity_decode($list->isi_komentar); ?> 
												</small>
												<small style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_komen), "d M Y H:i A")); ?></small>
											</div>
											<?php $media = explode(", ", $list->foto_video_konten_komen); ?>
											<?php $tgl = date_format(date_create($list->tgl_konten_2),"d-m-Y"); ?>
											<?php for($x = 0; $x < 1; $x++): ?>
												<?php if(strpos($media[$x], '.mp4')): ?>
													<video width="40" height="40" style="object-fit:none; margin-left: 16px;">
														<source src="<?php echo e(url('/data_file/'.$list->username_konten_2.'/foto_konten/'.$tgl.'/'.$list->slug.'/'.$media[$x])); ?>" type="video/mp4">
														<source src="<?php echo e(url('/data_file/'.$list->username_konten_2.'/foto_konten/'.$tgl.'/'.$list->slug.'/'.$media[$x])); ?>" type="video/ogg">
														Your browser does not support the video tag.
													</video>
												<?php else: ?>
													<img src="<?php echo e(url('/data_file/'.$list->username_konten_2.'/foto_konten/'.$tgl.'/'.$list->slug.'/'.$media[$x])); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
												<?php endif; ?>
											<?php endfor; ?>
										</div>
									</button>
								<?php elseif($list->jenis_notif == 'Post Grup'): ?>
									<button class="dropdown-item" type="button" onclick="location.href='/sosial-media/halaman_group_detail/<?php echo e($list->id_group); ?>';">
										<div class="media">
											<img src="<?php echo e((url('/data_file/'.$list->username_post.'/foto_profil/'.$list->foto_profil_post))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
											<div class="media-body align-self-center" style="white-space: initial; width:200px;">
												<small style="color: black"><b><?php echo e($list->username_post); ?></b> 
													memposting sesuatu di <strong><?php echo e($list->nama_group); ?></strong>
												</small>
												<small style="color: #989e99">-<?php echo e(date_format(date_create($list->created_at), "d M Y H:i A")); ?></small>
											</div>
										</div>
									</button>
								<?php elseif($list->jenis_notif == 'Undangan Grup'): ?>
									<button class="dropdown-item" type="button">
										<div class="media">
											<img src="<?php echo e((url('/data_file/'.$list->username_pengirim.'/foto_profil/'.$list->foto_pengirim))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
											<div class="media-body align-self-center" style="white-space: initial; width:200px; height: 90px;">
												<small style="color: black"><b><?php echo e($list->username_pengirim); ?></b> 
													mengundang anda ke dalam grup <strong><?php echo e($list->nama_group_undangan); ?></strong>
												</small>
												<small style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_undangan), "d M Y H:i A")); ?></small>
												<br>
												<a href="/sosial-media/terima_undangan_grup/<?php echo e($list->id); ?>" class="btn btn-success btn-sm" role="button" style="position: relative; top:10px; border: 1px solid #358f66; background: #358f66;">Terima</a>
												<a href="/sosial-media/tolak_undangan_grup/<?php echo e($list->id); ?>" class="btn btn-success btn-sm" role="button" style="position: relative; top:10px; border: 1px solid #358f66; background: #358f66;">Tolak</a>
											</div>
										</div>
									</button>
								<?php elseif($list->jenis_notif == 'Admin Grup'): ?>
									<button class="dropdown-item" type="button" onclick="location.href='/sosial-media/halaman_group_detail/<?php echo e($list->id_group_adm); ?>';">
										<div class="media">
											<img src="<?php echo e((url('/data_file/'.$list->username_admin_penambah.'/foto_profil/'.$list->foto_admin_penambah))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
											<div class="media-body align-self-center" style="white-space: initial; width:200px;">
												<small style="color: black"><b><?php echo e($list->username_admin_penambah); ?></b> 
												menjadikan Anda sebagai admin grup <b><?php echo e($list->nama_group_adm); ?></b>
												</small>
												<small style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_admin), "d M Y H:i A")); ?></small>
											</div>
										</div>
									</button>
								<?php elseif($list->jenis_notif == 'Followers'): ?>
									<?php if(strpos($list->isi_notif, "mengirim permintaan mengikuti") !== false): ?>
										<button class="dropdown-item" type="button">
											<div class="media">
												<img src="<?php echo e((url('/data_file/'.$list->username_requester.'/foto_profil/'.$list->foto_requester))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
												<?php if($list->status_request == 'Menunggu'): ?>
													<div class="media-body align-self-center" style="white-space: initial; width:200px; height: 90px;">
														<small style="color: black"><b><?php echo e($list->username_requester); ?></b> 
															mengirim permintaan mengikuti
														</small>
														<small style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_follow), "d M Y H:i A")); ?></small>
														<br>
														<a href="/sosial-media/terima_request/<?php echo e($list->id_request); ?>" class="btn btn-success btn-sm" role="button" style="position: relative; top:10px; border: 1px solid #358f66; background: #358f66;">Terima</a>
														<a href="/sosial-media/tolak_request/<?php echo e($list->id_request); ?>" class="btn btn-success btn-sm" role="button" style="position: relative; top:10px; border: 1px solid #358f66; background: #358f66;">Tolak</a>
													</div>
												<?php else: ?>
													<div class="media-body align-self-center" style="white-space: initial; width:200px;">
														<small style="color: black"><b><?php echo e($list->username_requester); ?></b> 
														mulai mengikuti Anda
														</small>
														<small style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_follow), "d M Y H:i A")); ?></small>
													</div>
												<?php endif; ?>
											</div>
										</button>
									<?php else: ?>
										<button class="dropdown-item" type="button">
											<div class="media">
												<img src="<?php echo e((url('/data_file/'.$list->username_followers.'/foto_profil/'.$list->foto_profil_followers))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
												<div class="media-body align-self-center" style="white-space: initial; width:200px;">
													<small style="color: black"><b><?php echo e($list->username_followers); ?></b> 
														mulai mengikuti Anda
													</small>
													<small style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_follow), "d M Y H:i A")); ?></small>
												</div>
											</div>
										</button>
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<div align="center"> Tidak Ada Notifikasi </div>
						<?php endif; ?>
						</div>
					</div>
				</li>
				<li class="nav-item">
					<a class="nav-link pesan" href="<?php echo e(asset('/sosial-media/chat')); ?>" title="Message" data-ripple="">
						<i class="fa fa-send-o" style="color:black;"></i> 
						<?php if(isset($notif_pesan)): ?>
							<?php $__currentLoopData = $notif_pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($notif->jml != 0): ?>
									<span class="badge badge-danger"><?php echo e($notif->jml); ?></span>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link group" href="<?php echo e(asset('/sosial-media/halaman_group')); ?>" title="Group" title="Group Notification" id="notif_group" data-ripple="">
						<i class="fa fa-group" style="color:black;"></i>
						<?php if(isset($notif_group)): ?>
							<?php $__currentLoopData = $notif_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($row->jml != 0): ?>
									<span class="badge badge-danger" id="jml_notif_group"><?php echo e($row->jml); ?></span>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle img_nav prof" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<img src="<?php echo e(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil)); ?>" alt="" style="height: 20px;width:20px;border-radius:50%;vertical-align:sub;">
					</a>
					<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="#" title=""><?php echo e(auth()->user()->name); ?></a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="/sosial-media/profil/<?php echo e(auth()->user()->pengguna->username); ?>" title=""><i class="ti-user" style="padding-right: 1rem;"></i>Profil</a>
						<!-- <a class="dropdown-item" href="" title=""><i class="fa fa-bar-chart-o" style="padding-right: 1rem;"></i>Insight</a> -->
						<a class="dropdown-item" href="/sosial-media/pengaturan" title=""><i class="ti-settings" style="padding-right: 1rem;"></i>Pengaturan</a>
						
						<a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="ti-power-off" style="padding-right: 1rem;"></i> Logout </a>
						<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
							<?php echo e(csrf_field()); ?>

						</form>
					</div>
				</li>
			<?php else: ?>
				<li class="nav-item">
					<a href="/sosial-media" class="nav-link notif">
						Login
					</a>
				</li>
			<?php endif; ?>
		</ul>
	</div>
<!-- </nav> -->