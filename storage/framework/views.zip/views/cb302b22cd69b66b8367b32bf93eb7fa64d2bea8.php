<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Sosial Media Desaku</title>
	<link rel="icon" href="/logo-home.png" type="image/png" sizes="16x16"> 
    
    
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('jquery-ui-1.12.1.custom/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slideshow.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/read-less-more.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/group-detail.css')); ?>">

    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/> -->
    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/> -->

</head>
<body style="overflow-y: auto;">
<!--<div class="se-pre-con"></div>-->
<div class="theme-layout">
	
	<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
		<?php echo $__env->make('theme.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</nav>
		
	<section>
		<div class="gap gray-bg">
			<div class="container-fluid">
			<?php if(Session::get('success')): ?>
			    <div class="alert alert-success">
			        <?php echo e(Session::get('success')); ?>

			        <button type="button" class="close" data-dismiss="alert">&times;</button>
			    </div>
			<?php endif; ?>
				<div class="row">
					<div class="col-lg-12">
						<div class="row" id="page-contents">
							<div class="col-lg-4" style="padding-right: 0px;">
								<aside class="sidebar static" style="margin-right: 0px;">
									<div class="widget static-widget stick-widget">
										<h4 class="widget-title">GROUP</h4>
										<ul class="naves">
											<li class="nav-item" style="margin-bottom: 0px;">
												<a class="nav-link active" href="/sosial-media/halaman_group" title="" style="padding-left: 0px;">Beranda</a>
											</li>
											<li class="nav-item" style="margin-bottom: 0px;">
												<button type="button" data-toggle="modal" data-target="#formBuatGrup" data-ripple="" class="btn outline-secondary btn-sm btn-block" style="border-radius: 3px;">Buat Grup Baru</button>
											</li>
										</ul>
										<div id="searchDir" style="padding-left: 25px; padding-right: 25px;"></div>
										<ul id="people-list" class="friendz-list" style="max-height: 200px;">
										<?php if($list_group_user): ?>
											<?php $__currentLoopData = $list_group_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li>
													<figure class="img_sampul_list<?php echo e($row->id_group); ?>">
														<img src="<?php echo e(url('/data_file/group/'.$row->nama_group.'/foto_sampul/'.$row->foto_sampul_group)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;">
													</figure>
													<div class="friendz-meta">
														<a href="/sosial-media/halaman_group_detail/<?php echo e($row->id_group); ?>" style="font-weight: 700;" class="nm_gr_list"><?php echo e($row->nama_group); ?></a>
														<?php $__currentLoopData = $jml_anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<?php if($row2->id_group == $row->id_group): ?>
																<span style="font-size: 12px;"><?php echo e($row2->jml_anggota); ?> anggota</span>
															<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php if($notif_group): ?>
															<?php $__currentLoopData = $notif_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															  	<?php if($row->id_group == $j->id_group): ?>
															  		<span class="badge pull-right align-self-center" style="margin-right: 5px;"><?php echo e($j->jml); ?></span>
															  	<?php endif; ?>
														  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													  	<?php endif; ?>
													</div>
												</li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
											<li style="text-align: center; font-weight: bold;">Belum Bergabung Dengan Grup</li>
										<?php endif; ?>
										</ul>
									</div>
								</aside>
							</div>
							<br>
							<div class="col-lg-7" style="padding-left: 20px;">
								<div class="central-meta" style="padding: 20px;">
									<section>
								    	<?php $__currentLoopData = $kueri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="feature-photo">
											<figure class="img_sampul_grup">
												<img src="<?php echo e(url('/data_file/group/'.$data->nama_group.'/foto_sampul/'.$data->foto_sampul_group)); ?>" alt="" style="width: 1366px; height: 200px;">
											</figure>
											<?php $array = array();
												foreach($list_admin as $adm){
													$array[] = $adm->id_admin;
												}
											?>
											<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array)): ?>
											<form class="edit-phto" style="bottom: 0px; left: 0px; height: 35px!important;" method="post" action="/sosial-media/ubah_foto_sampul">
												<i class="fa fa-camera-retro"></i>
												<label class="fileContainer">
													Ubah Foto Sampul
													<input type="file" name="foto_sampul_grup" id="ubah_sampul"/>
													<input type="hidden" name="id_group" value="<?php echo e($data->id_group); ?>" class="id_group"/>
													<input type="hidden" name="nama_group" value="<?php echo e($data->nama_group); ?>" class="nama_group"/>
												</label>
											</form>
											<?php endif; ?>
										</div>
										<?php break; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</section>
									<section class="col-lg-4" style="padding-left: 0px;">
										<div style="padding-top: 15px;">
											<h4 id="nm_gr" style="color: black; margin-bottom: 0px; display:inline;"><?php echo e($data->nama_group); ?></h4>
											<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array)): ?>
												<i class="ti-pencil edit_nama" style="font-size: 12px; cursor: pointer;" title="Edit Nama Group" onclick="editNama(<?php echo e($data->id_group); ?>);"></i>
											<?php endif; ?>
											<?php $__currentLoopData = $data_anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($data->id_group == $data2->id_group): ?>
													<span style="font-size: 12px; display: block;"><?php echo e($data2->jml_anggota); ?> anggota</span>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</section>
									<section class="col-lg-5" style="padding-left: 0px;">
										<div style="padding-top: 15px;">
											<div class="users-thumb-list" style="margin-top: 0px; text-align: right;">
											<?php $__currentLoopData = $list_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<a href="/sosial-media/profil/<?php echo e($row->username); ?>" title="<?php echo e($row->nama); ?>" data-toggle="tooltip" style="display: inline-block; margin-left: -17px;">
													<img src="<?php echo e(url('/data_file/'.$row->username.'/foto_profil/'.$row->foto_profil)); ?>" style="border: 2px solid #fff; border-radius: 50%; width: 36px; height: 36px; object-fit: cover;">  
												</a>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
										</div>
									</section>
									<section class="col-lg-3" style="padding-right: 0px;">
										<div style="padding-top: 15px; float: right;">
										<?php $array_anggota = array();
											foreach($list_group as $anggota){
												$array_anggota[] = $anggota->id_pengguna;
											}
										?>
										<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array_anggota)): ?>
											<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modalInvite"  style="position: relative;">Undang Teman</button>
											<div class="btn-group">
												<button type="button" class="btn btn-sm btn-primary" style="position: relative;" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></button>
												<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
												    <!-- <button class="dropdown-item" type="button">Action</button> -->
												    <button class="dropdown-item" type="button"><a href="#" onclick="keluarGrup('<?php echo e($data->id_group); ?>', '<?php echo e($data->nama_group); ?>', '<?php echo e($data->foto_sampul_group); ?>')" style="color: red;">Keluar Dari Group</a></button>
												    <?php if(in_array(auth()->user()->pengguna->id_pengguna, $array)): ?>
													<div class="dropdown-divider"></div>
												    <button class="dropdown-item" type="button" onclick="hapusGrup('<?php echo e($data->id_group); ?>', '<?php echo e($data->nama_group); ?>', '<?php echo e($data->foto_sampul_group); ?>')" style="cursor: pointer; background: red; color: white">Hapus Group</button>
												    <?php endif; ?>
												</div>
											</div>
										<?php else: ?>
											<a href="/sosial-media/gabung_grup/<?php echo e($data->id_group); ?>"><button type="button" class="btn btn-sm btn-primary" style="position: relative;">Gabung Grup</button></a>
										<?php endif; ?>
										</div>
									</section>
								</div>
								<div class="modal fade" id="modalInvite" role="dialog">
								    <div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 400px;">
								      	<div class="modal-content">
									        <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
									          	<h6 class="modal-title">Undang Teman</h6>
									        </div>
							        		<div class="input-group flex-nowrap" id="cari_teman">
							        			<div class="input-group-prepend">
											    	<span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
											    		Ke: 
											    	</span>
												</div>
												<!-- <input type="text" class="form-control form-control-sm" placeholder="cari.." style="border-radius: 0rem;"> -->
												<div id="kolom_input_cari" style="width: 100%;"></div>
											</div>
											<form method="post" action="/sosial-media/undangan_grup_proses" enctype="multipart/form-data">
											<?php echo e(csrf_field()); ?>

									        	<ul class="friendz-list list-group list-group-flush" style="margin-top: 0px; overflow-y: auto!important; max-height: 250px;" id="teman_yang_dicari">
										        	<?php if($teman != NULL): ?>
														<?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<div class="list-group list-group-flush" style="max-height: 315px;">
												        	<a class="list-group-item list-group-item-action" style="padding-right: 10px; padding-left: 10px;">
												        		<div class="input-group mb-3" style="margin-bottom: 0px;">
													        		<div class="media">
																		<img src="<?php echo e(url('/data_file/'.$data2->username.'/foto_profil/'.$data2->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
																	  	<div class="media-body align-self-center">
																	  		<small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data2->username); ?></small><br>
																	    	<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data2->nama); ?></small>
																	  	</div>
																	</div>
																	<div class="input-group-append" style="position: absolute;right: 0;top: 35%;">
																    	<!-- <div class="input-group-text" style="background-color: #fff; border-color: #fff;"> -->
																      		<input type="checkbox" name="pilih_teman[]" value="<?php echo e($data2->id_pengguna); ?>" aria-label="Checkbox for following text input">
																    	<!-- </div> -->
																    </div>
																</div>
												        	</a>
												        </div>
										        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
													<?php else: ?>
														<li>
															<div align="center">Tidak ada teman</div>
														</li>
													<?php endif; ?>
									        	</ul>
									        	<input type="hidden" name="id_group" value="<?php echo e($data->id_group); ?>"></input>
									        	<div class="modal-footer" style="padding: 8px;">
										      		<input class="btn btn-sm btn-submit" type="submit" style="background-color: #358f66; color: white;" value="Submit"></input> 
										      	</div>
										    </form>
								      	</div>
								    </div>
								</div>
								<div class="col-lg-12">
									<div class="row" id="page-contents">
										<div class="col-lg-8" style="padding-left: 0px; padding-right: 15px;">
											<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array_anggota)): ?>
											<div class="central-meta item">
												<div class="new-postbox">
													<!-- <figure>
														<img src="<?php echo e(asset('user.jpg')); ?>" alt="">
													</figure> -->
													<div class="newpst-input" style="margin-right: 0px; margin-left: 0px; width: 100%;">
														<form method="post" action="/sosial-media/post_konten_grup" enctype="multipart/form-data">
														<?php echo e(csrf_field()); ?>

															<div class="form-group">
																<input type="text" name="tempat" id="tempat" style="border:1px solid #eeeeee; background-color: white; padding: 10px;" placeholder="Pilih Lokasi" required />
																<input type="hidden" id="long" name="longitude_tempat">
																<input type="hidden" id="lat" name="latitude_tempat">
															</div>
															<input type="hidden" name="id_group" value="<?php echo e($data->id_group); ?>"></input>
															<input type="hidden" name="nama_group" value="<?php echo e($data->nama_group); ?>"></input>
															<textarea rows="3" name="caption" placeholder="write something" id="caption_post" maxlength="500"  onkeyup="countChars(this);" required></textarea>
															<div class="attachments">
																<ul>
																	<li><small id="charNum" style="margin:0;">500/500</small></li>
																	<li>
																		<i class="fa fa-image"></i>
																		<label class="fileContainer">
																			<input type="file" name="file_foto[]" id="pro-imagee" required multiple> <!-- id="pro-image" -->
																		</label>
																	</li>
																	<li>
																		<button type="submit">Post</button>
																	</li>
																</ul>
															</div>
														</form>
														<div class="preview-images-zone"></div>
													</div>
												</div>
											</div><!-- add post new box -->
											<div id="map"></div>
											<?php endif; ?>
											<div>
												<?php $nm_grp = $data->nama_group; $id_grp = $data->id_group; ?>
												<?php if(isset($konten)): ?>
													<?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="central-meta item">
														<div class="user-post">
															<div class="friend-info">
																<figure>
																	<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_profil/'.$data->foto_profil)); ?>" alt="" style="width: 35px; height: 35px;">
																</figure>
																<div class="friend-name">
																	<ins><a href="/sosial-media/profil/<?php echo e($data->username); ?>" title=""><?php echo e($data->username); ?></a></ins>
																	<span style="color: black;"><a><?php echo e($data->tempat); ?></a></span>
																	<div class="d-flex justify-content-end">
																	<?php $tgl = date_format(date_create($data->created_at), "d-m-Y"); ?>
																	<?php if(($data->username) != auth()->user()->pengguna->username): ?>
																		<a onclick="modalMore('<?php echo e($data->id_konten); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->slug); ?>', '<?php echo e($data->foto_profil); ?>')" style="cursor: pointer;"><i class="fa fa-ellipsis-v"></i></a>
																	<?php else: ?>
																		<a onclick="modalMore2('<?php echo e($data->id_konten); ?>', '<?php echo e($data->foto_profil); ?>', '<?php echo e($nm_grp); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->tempat); ?>', '<?php echo e($data->foto_video_konten); ?>', '<?php echo e($data->caption); ?>', '<?php echo e($tgl); ?>', '<?php echo e($data->slug); ?>')" style="cursor: pointer;"><i class="fa fa-ellipsis-v"></i></a>
																	<?php endif; ?>
																	</div>
																</div>
																<div class="post-meta">
																	<div class="single-item">
																	<?php $media = explode(", ", $data->foto_video_konten); ?>
																	<?php $tgl = date_format(date_create($data->created_at),"d-m-Y"); ?>
																	<?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media_konten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<?php if(strpos($media_konten, '.mp4')): ?>
																			<video width="100%" height="100%" autoplay loop muted>
																			  	<source src="<?php echo e(url('/data_file/group/'.$nm_grp.'/foto_konten/'.$tgl.'/'.$data->slug.'/'.$media_konten)); ?>" type="video/mp4">
																			  	<source src="<?php echo e(url('/data_file/group/'.$nm_grp.'/foto_konten/'.$tgl.'/'.$data->slug.'/'.$media_konten)); ?>" type="video/ogg">
																			  	Your browser does not support the video tag.
																			</video>
																		<?php else: ?>
																			<img src="<?php echo e(url('/data_file/group/'.$nm_grp.'/foto_konten/'.$tgl.'/'.$data->slug.'/'.$media_konten)); ?>" alt="">
																		<?php endif; ?>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	</div>
																	<div class="we-video-info" style="padding-top: 5px; padding-bottom: 0;">
																		<ul style="max-height: 30px;">
																			<li data-id="<?php echo e($data->id_konten); ?>" data-is-like="<?php echo e($data->is_like ? 1 : 0); ?>" class="action-like-or-dislike" style="margin-right: 5px;height: 23px;">
																				<span class="like" data-toggle="tooltip" title="<?php echo e($data->is_like ? 'Batal Menyukai' : 'Menyukai'); ?>">
																					<div class="menu" style="width: 23px; height: 23px;">
																						<div class="btn trigger" style="background: none;">
																							<i id="icon_like<?php echo e($data->id_konten); ?>" class="<?php echo e($data->is_like ? 'fa fa-heart' : 'fa fa-heart-o'); ?>" style="font-size: 20px;color: black;"></i>
																						</div>
																					</div>
																				</span>
																			</li>
																			<li class="social-media" style="margin-right: 5px; height: 23px; position: absolute;">
																				<span class="like">
																					<div class="menu" style="width: 23px; height: 23px;">
																						<div class="btn trigger" style="background: none;">
																							<i class="fa fa-share-alt" style="color: black; font-size: 20px;"></i>
																						</div>
																						<?php

																							$url = urlencode("http://127.0.0.1:8000/sosial-media/group/p/".$data->slug);
																							$media = explode(", ", $data->foto_video_konten); $i=1;
																							foreach ($media as $media_konten){
																								$img = urlencode(url('/data_file/'.$media_konten));
																								if($loop->iteration == 1){
																									break;
																								}
																							}
																							$title = $data->username;
																							$summary = $data->caption;

																						?>
																						<div class="rotater">
																							<div class="btn btn-icon"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>&display=popup" target="_blank" title=""><i class="fa fa-facebook"></i></a></div>
																						</div>
																						<div class="rotater">
																							<div class="btn btn-icon"><a href="https://twitter.com/intent/tweet?url=<?php echo e($url); ?>" target="_blank" title=""><i class="fa fa-twitter"></i></a></div>
																						</div>
																						<div class="rotater">
																							<div class="btn btn-icon"><a href="whatsapp://send?text=<?php echo e($url); ?>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" title=""><i class="fa fa-whatsapp"></i></a>
																							</div>
																						</div>
																					</div>
																				</span>
																			</li>
																		</ul>
																	</div>
																	<?php if($likes): ?>
																		<?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																			<?php if($like->id_konten == $data->id_konten): ?>
																				<p style="margin-bottom: 0px;">Disukai oleh <a href="/sosial-media/profil/<?php echo e($like->username); ?>"><b><?php echo e($like->username); ?></b></a> dan<span style="cursor: pointer;" data-toggle="modal" data-target="#modalLike<?php echo e($data->id_konten); ?>"> <b>lainnya</b></span></p>
																				<?php if(COUNT($like->username) == 1): ?>
																				<?php break; ?>
																				<?php endif; ?>
																			<?php endif; ?>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	<?php endif; ?>
																	<div class="description" style="margin-top: 0;">
																		<p style="margin-bottom: 0px;"> 
																			<strong><?php echo e($data->username); ?></strong> <span class="addReadMore showlesscontent"><?php echo e($data->caption); ?></span>
																		</p>
																		<span style="color: #999; float: left;font-size: 12px;text-transform: capitalize;width: 100%;">
																			<?php echo date_format(date_create($data->created_at), "d M Y H:i A"); ?>
																		</span>
																	</div>
																</div>
															</div>
															<div class="modal fade" id="modalLike<?php echo e($data->id_konten); ?>" role="dialog">
																<div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 400px;">
																	<div class="modal-content">
																		<div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
																			<h6 class="modal-title">Menyukai</h6>
																		</div>
																		<ul class="friendz-list list-group list-group-flush" style="overflow-y: auto!important; max-height: 250px;">
																			<?php if($likes_all != NULL): ?>
																				<?php $__currentLoopData = $likes_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<?php if($data2->id_konten == $data->id_konten): ?>
																						<div class="list-group list-group-flush" style="max-height: 315px;">
																							<a href="#" class="list-group-item list-group-item-action" data-dismiss="modal" style="padding-left: 10px; padding-right: 10px;">
																								<div class="media">
																									<img src="<?php echo e(url('/data_file/'.$data2->username.'/foto_profil/'.$data2->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
																									<div class="media-body align-self-center">
																										<small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data2->username); ?></small><br>
																										<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data2->nama); ?></small>
																									</div>
																								</div>
																							</a>
																						</div>
																					<?php endif; ?>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			<?php endif; ?>
																		</ul>
																	</div>
																</div>
															</div>
															<div class="coment-area">
																<ul class="we-comet list-cmt<?php echo e($data->id_konten); ?>" style="overflow-y: auto; max-height: 200px;">
																	<?php if(isset($komentar)): ?>
																		<?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																			<?php if(isset($dataa->isi_komentar)): ?>
																				<?php if(($data->id_konten == $dataa->id_konten) && $dataa->id_balas_komen == 0): ?>
																					<li id="comment_<?php echo e($dataa->id_cmt); ?>" class="list-rep_cmt_<?php echo e($dataa->id_cmt); ?>">
																						<div class="comet-avatar">
																							<img src="<?php echo e(url('/data_file/'.$dataa->username.'/foto_profil/'.$dataa->foto_profil)); ?>" alt="" style="height: 45px; width: 45px;">
																						</div>
																						<div class="we-comment" style="width:50%;">
																							<div class="coment-head">
																								<h5 style="text-transform: none;"><a href="/sosial-media/profil/<?php echo e($dataa->username); ?>" title=""><?php echo e($dataa->username); ?></a></h5>
																								<span><?php echo e(date_format(date_create($dataa->tanggal_komen), "d M Y H:i A")); ?></span>
																								<!-- <a class="we-reply" href="#" title="Reply"><i class="fa fa-reply"></i></a> -->
																								<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array_anggota)): ?>
																								
																								<?php if((Auth::user()->pengguna->username == $dataa->username) OR (Auth::user()->pengguna->username == $data->username)): ?>
																								<a onclick="modalHapusKomentar('<?php echo e($dataa->id_cmt); ?>')" style="cursor: pointer"><i class="ti-trash hide" style="color: red;"></i></a>
																								<?php endif; ?>
																								<?php if(Auth::user()->pengguna->username != $dataa->username): ?>
																								<a onclick="modalReportKomentar('<?php echo e($dataa->id_cmt); ?>')" style="cursor: pointer" title="Report Komentar"><i class="ti-info-alt hide" style="color: red;"></i></a>
																								<?php endif; ?>
																								<button class="we-reply btn btn-link" style="font-size: 12px; font-weight: 500; float: right;position: relative;top: 0;"  onclick="balas_komen('<?php echo e('@'.$dataa->username); ?>', '<?php echo e($dataa->id_cmt); ?>', '<?php echo e($dataa->username); ?>', '<?php echo e($data->id_konten); ?>')" value="<?php echo e($dataa->id_cmt); ?>">Balas</button>
																								<?php endif; ?>
																							</div>
																							<p style="margin-top: 0px;"><?php echo e($dataa->isi_komentar); ?></p>
																						</div>
																						<?php $id_cmt_parent = $dataa->id_cmt; ?>
																						<?php if(isset($balas_komentar)): ?>
																						<?php $__currentLoopData = $balas_komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balas_komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																						<?php if($balas_komen->id_balas_komen != 0): ?>
																						<?php if($dataa->id_cmt == $balas_komen->id_balas_komen): ?>
																						<ul id="comment_<?php echo e($dataa->id_cmt); ?>">
																							<li>
																								<div class="comet-avatar">
																									<img src="<?php echo e(url('/data_file/'.$balas_komen->username.'/foto_profil/'.$balas_komen->foto_profil)); ?>" alt="" style="height: 30px; width: 30px;">
																								</div>
																								<div class="we-comment">
																									<div class="coment-head">
																										<h5 style="text-transform: none;"><a href="/sosial-media/profil/<?php echo e($balas_komen->username); ?>" title=""><?php echo e($balas_komen->username); ?></a></h5>
																										<span style="text-overflow: ellipsis;white-space: nowrap;width: 100px;"><?php echo e(date_format(date_create($balas_komen->tanggal_komen), "d M Y H:i A")); ?></span>
																										<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array_anggota)): ?>
																										
																										<?php if((Auth::user()->pengguna->username == $balas_komen->username) OR (Auth::user()->pengguna->username == $data->username)): ?>
																										<a onclick="modalHapusKomentar('<?php echo e($balas_komen->id_cmt); ?>')" style="cursor: pointer"><i class="ti-trash hide" style="color: red;"></i></a>
																										<?php endif; ?>
																										<?php if(Auth::user()->pengguna->username != $balas_komen->username): ?>
																										<a onclick="modalReportKomentar('<?php echo e($balas_komen->id_cmt); ?>')" style="cursor: pointer" title="Report Komentar"><i class="ti-info-alt hide" style="color: red;"></i></a>
																										<?php endif; ?>
																										<button class="we-reply btn btn-link" style="font-size: 12px; font-weight: 500; float: right;position: relative;top: 0;"  onclick="balas_komen('<?php echo e('@'.$balas_komen->username); ?>', '<?php echo e($id_cmt_parent); ?>', '<?php echo e($balas_komen->username); ?>', '<?php echo e($data->id_konten); ?>')" value="<?php echo e($balas_komen->id_cmt); ?>">Balas</button>
																										<?php endif; ?>
																									</div>
																									<p style="margin-top: 0px;"><?php echo  html_entity_decode($balas_komen->isi_komentar) ?></p>
																								</div>
																							</li>
																						</ul>
																						<?php endif; ?>
																						<?php endif; ?>
																						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																						<?php endif; ?>
																					</li>
																					
																					<!-- <li>
																						<a href="#" title="" class="showmore underline">more comments</a>
																					</li> -->
																				<?php endif; ?>
																			<?php endif; ?>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	<?php endif; ?>
																</ul>
																<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array_anggota)): ?>
																<ul class="we-comet">
																	<li class="post-comment">
																		<div class="comet-avatar" style="width: 9%; max-width: 9%;">
																			<img src="<?php echo e(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil)); ?>" alt="" value="<?php echo e(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil)); ?>" style="width: 35px; height: 35px;">
																		</div>
																		<div class="post-comt-box2" style="width: 90%;"> <!-- post-comt-box -->
																			<form method="post" action="/sosial-media/post_komen_grup" enctype="multipart/form-data">
																			<?php echo e(csrf_field()); ?>

																				<input type="hidden" name="id_konten" value="<?php echo e($data->id_konten); ?>" class="konten_<?php echo e($data->id_konten); ?>">
																				<span class="thumb-xs<?php echo e($data->id_konten); ?>">
																					<textarea placeholder="Post your comment" name="isi_komentar" style="width: 90%;" class="txt_comment_<?php echo e($data->id_konten); ?>"></textarea>
																				</span>
																				
																				<button type="button" onclick="uploadKomen('<?php echo e($data->id_konten); ?>')" class="btn btn-submit" style="border-radius: 3px;">Post</button>
																			</form>	
																		</div>
																	</li>
																</ul>
																<?php endif; ?>
															</div>
														</div>
													</div>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
											</div>
										</div>		
										<?php $__currentLoopData = $kueri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="col-lg-4" style="padding-right: 0px;padding-left: 0px;">
											<aside class="sidebar static" style="margin-right: 0px;width: 100%;">
												<div class="widget">
													<h4 class="widget-title">Tentang Group</h4>	
													<div class="your-page">
														<div class="page-meta" style="padding-left: 0px; width: 100%;">
															<span id="desc_gr" style="display: inline;"><?php echo e($row->deskripsi_group); ?></span>
															<?php
																$array = array();
																foreach($list_admin as $adm){
																	$array[] = $adm->id_admin;
																}
															?>
															<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array)): ?>
															<i class="ti-pencil edit_desc" style="font-size: 12px; cursor: pointer;" title="Edit Deskripsi" onclick="editDesc(<?php echo e($row->id_group); ?>);"></i>
															<?php endif; ?>
															<span>
																<strong>Admin: 
																<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array)): ?>
																	<i class="ti-plus" style="float: right; border: 1px solid; border-radius: 50%; font-weight: bold; font-size: 10px; padding: 3px; cursor: pointer;" data-toggle="modal" data-target="#modalTambahAdmin"></i>
																<?php endif; ?>
																</strong>
																<div class="users-thumb-list" style="margin-top: 0px; text-align: left; padding-left: 15px; padding-right: 15px;">
																	<?php $__currentLoopData = $list_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_adm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<a href="/sosial-media/profil/<?php echo e($row_adm->username); ?>" title="<?php echo e($row_adm->nama); ?>" data-toggle="tooltip" style="display: inline-block; margin-left: -17px;">
																			<img src="<?php echo e(url('/data_file/'.$row_adm->username.'/foto_profil/'.$row_adm->foto_profil)); ?>" style="border: 2px solid #fff; border-radius: 50%; width: 36px; height: 36px; object-fit: cover;">  
																		</a>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																</div>
																<?php if(in_array(auth()->user()->pengguna->id_pengguna, $array)): ?>
																<a class="btn btn-sm btn-block btn-danger" style="font-weight: bold; color: white; margin-top: 50px;" href="/sosial-media/list-report-grup/<?php echo e($row->id_group); ?>"> List Report <span class="badge badge-warning"><?php echo e(COUNT($data_rp) >= 1 ? COUNT($data_rp) : ''); ?></span></a>
																<?php endif; ?>
															</span>
														</div>
													</div>
												</div><!-- page like widget -->
												<!-- <div class="widget friend-list stick-widget"> -->
												<div class="widget friend-list stick-widget">
													<h4 class="widget-title">Daftar Anggota</h4>
													<div id="searchDir2"></div>
													<ul id="people-list2" class="friendz-list" style="max-height: 200px;">
													<?php $__currentLoopData = $list_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li>
															<figure>
																<img src="<?php echo e(url('/data_file/'.$row->username.'/foto_profil/'.$row->foto_profil)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;">
															</figure>
															<div class="friendz-meta">
																<a href="/sosial-media/profil/<?php echo e($row->username); ?>"><?php echo e($row->nama_anggota); ?></a>
															</div>
														</li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>
												</div><!-- friends list sidebar -->
											</aside>
										</div><!-- sidebar -->
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
						</div>	
					</div>
				</div>
			</div>
		</div>	
	</section>
	<div class="modal fade" id="modalTambahAdmin" role="dialog">
	    <div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 400px;">
	      	<div class="modal-content">
		        <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
		          	<h6 class="modal-title">Tambah Admin</h6>
		        </div>
        		<div class="input-group flex-nowrap" id="cari_admin">
        			<div class="input-group-prepend">
				    	<span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
				    		Ke: 
				    	</span>
					</div>
					<div id="kolom_input_cari_admin" style="width: 100%;"></div>
				</div>
				<form method="post" action="/sosial-media/tambah_admin" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

		        	<ul class="friendz-list list-group list-group-flush" style="margin-top: 0px; overflow-y: auto!important; max-height: 250px;" id="admin_yang_dicari">
			        	<?php if($list_group != NULL): ?>
							<?php $__currentLoopData = $list_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($row->username !== auth()->user()->pengguna->username): ?>
									<div class="list-group list-group-flush" style="max-height: 315px;">
							        	<a class="list-group-item list-group-item-action" style="padding-right: 10px; padding-left: 10px;">
							        		<div class="input-group mb-3" style="margin-bottom: 0px;">
								        		<div class="media">
													<img src="<?php echo e(url('/data_file/'.$row->username.'/foto_profil/'.$row->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
												  	<div class="media-body align-self-center">
												  		<small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($row->username); ?></small><br>
												    	<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($row->nama); ?></small>
												  	</div>
												</div>
												<div class="input-group-append" style="position: absolute;right: 0;top: 35%;">
											      	<input type="checkbox" name="pilih_admin[]" value="<?php echo e($row->id_pengguna); ?>" aria-label="Checkbox for following text input">
											    </div>
											</div>
							        	</a>
							        </div>
								<?php endif; ?>
			        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						<?php endif; ?>
		        	</ul>
		        	<input type="hidden" name="id_group" value="<?php echo e($data->id_group); ?>"></input>
		        	<div class="modal-footer" style="padding: 8px;">
			      		<input class="btn btn-sm btn-submit" type="submit" style="background-color: #358f66; color: white;" value="Tambah"></input> 
			      	</div>
			    </form>
	      	</div>
	    </div>
	</div>
	<div class="modal fade" id="formBuatGrup" role="dialog">
	    <div class="modal-dialog modal-dialog-centered" style="max-width: 600px;">
	    	<form method="post" action="/sosial-media/buat_group_proses" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

		      	<div class="modal-content">
		      		<div class="modal-header" style="padding-top: 8px; padding-bottom: 8px;">
				        <h5 class="modal-title">Buat Group Baru</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				          <span aria-hidden="true">&times;</span>
				        </button>
				    </div>
		        	<div class="modal-body" style="padding-top: 8px; padding-bottom: 8px;">
						<div class="form-group half" style="width: auto;">
							<figure class="foto_sampul align-self-center" style="margin-bottom: 0;">
								<img src="<?php echo e(asset('user.jpg')); ?>" alt="" style="height: 50px; border-radius: 50%;">
							</figure>
						</div>
						<div class="form-group half">
							<label for="foto_profil" style="left: 0; margin-bottom: 0;">Foto Sampul Group</label>
						  	<input type="file" id="foto_sampul" name="foto_sampul" required="required"/>
						</div>
						<div class="form-group half" id="nama_prov">
							<select class="form-control nama_prov" name="nama_prov" style="color: black;" required>
								<option disabled selected>-- Pilih Provinsi --</option>
								<?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($data->name); ?>+++<?php echo e($data->id); ?>" style="text-transform: capitalize;"> <?php echo e(ucwords(html_entity_decode(strtolower($data->name)))); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="form-group half" id="nama_kab">
							<select class="form-control nama_kab" name="nama_kab" style="color: black;" required>
								<option disabled selected>-- Pilih Kabupaten --</option>
							</select>
						</div>
						<div class="form-group half" id="nama_kec" style="margin-right: 0;">
							<select class="form-control nama_kec" name="nama_kec" style="color: black;" required>
								<option disabled selected>-- Pilih Kecamatan --</option>
							</select>
						</div>
						<div class="form-group half" id="nama_des" style="float: right; margin-right: 0;">
							<select class="form-control nama_des" name="nama_des" style="color: black;" required>
								<option disabled selected>-- Pilih Desa --</option>
							</select>
						</div>
		        		<div class="form-group">	
						  	<input type="text" id="input" name="nama_group" required="required"/>
						  	<label class="control-label" for="input" style="left: 0;">Nama Group</label><i class="mtrl-select"></i>
						</div>
						<div class="form-group">	
						  	<textarea rows="2" id="textarea" name="deskripsi_group" required="required" maxlength="70"></textarea>
						  	<label class="control-label" for="textarea" style="left: 0;">Deskripsi Group</label><i class="mtrl-select"></i>
						  	<span style="font-size: 12px; color: red;">*maks. 70 huruf</span>
						</div>
			      	</div>
			      	<div class="modal-footer" style="padding-top: 8px; padding-bottom: 8px;">
			      		<input class="btn btn-sm btn-submit" type="submit" style="background-color: #358f66; color: white;" value="Submit"></input> 
			      	</div>
		      	</div>
		    </form>
	    </div>
	</div>

</div>

<div class="modal fade" id="myModalEdit" role="dialog">
    <div class="modal-dialog" style="max-width: 600px;">
        <form method="post" action="/sosial-media/edit_konten_proses" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Konten</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="closebtn" value="">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="text-align: center;">
                    <div class="friend-info" style="text-align: left; margin-bottom: 15px;">
                        <figure style="width: 10%;">
                            <img id="foto_post" src="" alt="" style="width: 45px; height: 45px; border-radius: 50%;">
                        </figure>
                        <div class="friend-name" style="width:85%; padding-left: 0px;">
                            <ins>
                                <a id="uname" href="" title=""></a>
                            </ins>
                            <span id="tmpt" style="color: black;"></span>
                        </div>
                    </div>
                    <div class="wrap-modal-slider">
                        <div class="slideshow-container editSlide">
                            <div id="media_post"></div>
                            <a class="prev" onclick="" id="prevClick">&#10094;</a>
                            <a class="next" onclick="" id="nextClick">&#10095;</a>
                        </div>
                    </div>
					<div class="newpst-input" style="margin-top: 15px;">
						<input type="hidden" name="id_konten" id="hidden_id" value=""></input>
						<textarea rows="3" name="caption" id="capt" style="border: 1px solid #eeeeee; border-radius: 0; border-bottom: 0;"  onkeyup="countCharsEdit(this);" maxlenght="500"></textarea>
						<div class="attachments">
                            <ul>
                                <li><small id="charNumEdit" style="margin:0;"></small></li>
                            </ul>
                        </div>
					</div>
                </div>
                <div class="modal-footer">
                    <input class="btn btn-sm btn-submit" type="submit" style="background-color: #358f66; color: white;" value="Update"></input>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalShare" role="dialog">
    <div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 400px;">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
                <h6 class="modal-title">Bagikan</h6>
            </div>
            <div class="input-group flex-nowrap searchKey" id="cari_teman_2">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
                        Ke: 
                    </span>
                </div>
                <div id="kolom_input_cari_2" class="kolom_cari" style="width: 100%;"></div>
            </div>
            <form method="post" action="/sosial-media/share_post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

                <ul class="friendz-list list-group list-group-flush findFr" style="margin-top: 0px; overflow-y: auto!important; max-height: 250px;" id="teman_yang_dicari_2">
                    <?php if($teman != NULL): ?> 
                        <?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group list-group-flush" style="max-height: 315px;">
                            <a class="list-group-item list-group-item-action" style="padding-right: 10px; padding-left: 10px;">
                                <div class="input-group mb-3" style="margin-bottom: 0px!important;">
                                    <div class="media">
                                        <img src="<?php echo e(url('/data_file/'.$data2->username.'/foto_profil/'.$data2->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
                                        <div class="media-body align-self-center">
                                            <small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data2->username); ?></small><br>
                                            <small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data2->nama); ?></small>
                                        </div>
                                    </div>
                                    <div class="input-group-append" style="position: absolute;right: 0;top: 35%;">
                                        <input type="checkbox" name="pilih_teman[]" value="<?php echo e($data2->id_pengguna); ?>" aria-label="Checkbox for following text input">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php else: ?>
                        <li>
                            <div align="center">Tidak ada teman</div>
                        </li>
                    <?php endif; ?>
                </ul>
                <input type="hidden" name="id_konten" id="hidden_id_share" value=""></input>
                <div class="modal-footer" style="padding: 8px;">
                    <input class="btn btn-sm btn-submit" type="submit" style="background-color: #358f66; color: white;" value="Submit"></input> 
                </div>
            </form>
        </div>
    </div>
</div>	

<div class="modal fade" id="modalReport" role="dialog">
    <div class="modal-dialog modal-sm" style="max-width: 600px;">
        <form method="post" action="/sosial-media/report_proses" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Report <span class="kategori_report"></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="text-align: left;">
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Alasan Pelaporan <span class="kategori_report"></span></label>
                        <select class="form-control" id="alasan_report" name="alasan_report">
                            <option selected disabled>Pilih Alasan</option>
                            <option value="Spam">Spam</option>
                            <option value="Ujaran / Simbol Kebencian">Ujaran / Simbol Kebencian</option>
                            <option value="Ketelanjangan / Aktivitas Seksual">Ketelanjangan / Aktivitas Seksual</option>
                            <option value="Kekerasan / Organisasi Berbahaya">Kekerasan / Organisasi Berbahaya</option>
                            <option value="Penipuan">Penipuan</option>
                            <option value="Informasi Palsu">Informasi Palsu</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="kategori" name="kategori_report" value=""/>
                    <input type="hidden" name="acct_reporter" value="<?php echo e(Auth::user()->pengguna->id_pengguna); ?>"/>
                    <input type="hidden" id="reported" name="id_reported" value=""/>
                    <input class="btn btn-sm btn-submit" type="submit" style="background-color: red; color: white;" value="Report"></input>
                </div>
            </div>
        </form>
    </div>
</div>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/script.js')); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slideshow.js')); ?>"></script>
<script src="<?php echo e(asset('js/read-less-more.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('slick-1.8.1/slick/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/group-detail.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-iHgzDAzd_uS3biSkqVRw_sxAoqS1o04&libraries=places&callback=initMap" async defer></script>
<script type="text/javascript">

    // CSRF Token
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function(){

      $( "#search" ).autocomplete({
      	appendTo: "#container_search",
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url:"<?php echo e(route('sosial-media.cari_pengguna')); ?>",
            type: 'post',
            dataType: "json",
            data: {
               _token: CSRF_TOKEN,
               search: request.term
            },
            success: function( data ) {
               response( data );
            }
          });
        },
        select: function (event, ui) {
           let username = ui.item.value;
           window.location.href = window.location.origin+"/sosial-media/profil/"+username;
           return false;
        }
      })
      .data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	      return $( "<li>" )
	        .append( "<div class='media'><img src='"+item.icon+"' class='align-self-center mr-3' alt='...' style='width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;'> <div class='media-body align-self-center'> <small style='font-weight: 700; color: black; margin-bottom: 0rem;'>"+item.value+"</small><br><small class='mt-0' style='margin-bottom: 0rem; font-weight: 500; color: #989e99;'>"+item.label+"</small>")
	        .appendTo( ul );
	  };

    });

	// var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
	// $('#notif').click(function () {
	// 	$.ajax({
	// 		url: "<?php echo e(route('sosial-media.update_notif')); ?>",
	// 		type: 'post',
	// 		// dataType: "json",
	// 		data: {
	// 			_token: CSRF_TOKEN
	// 		},
	// 		success: function (data) {
	// 			if (document.getElementById("jml_notif")) {
	// 				document.getElementById("jml_notif").style.visibility = "hidden";
	// 			}
	// 		}
	// 	});
	// });
</script>
</body>	

</html>