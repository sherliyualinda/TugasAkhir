<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Sosial Media Desaku</title>
	<link rel="icon" href="/logo-home.png" type="image/png" sizes="16x16"> 
    
    
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('jquery-ui-1.12.1.custom/jquery-ui.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pengaturan-password.css')); ?>">

</head>
<body style="overflow-y: hidden;">
<!--<div class="se-pre-con"></div>-->
<div class="theme-layout">
	
	<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
		<?php echo $__env->make('theme.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</nav>
		
	<section>
		<div class="gap gray-bg">
			<?php if(Session::get('success')): ?>
			    <div class="alert alert-success">
			        <?php echo e(Session::get('success')); ?>

			        <button type="button" class="close" data-dismiss="alert">&times;</button>
			    </div>
			<?php elseif(Session::get('alert')): ?>
				<div class="alert alert-danger">
			        <?php echo e(Session::get('alert')); ?>

			        <button type="button" class="close" data-dismiss="alert">&times;</button>
			    </div>
			<?php endif; ?>
			<div class="container-fluid">
				<div class="row" style="padding-left: 10px;">
					<div class="col-lg-12">
						<div class="row justify-content-center" id="page-contents" style="padding-left: 0;">
							<div class="central-meta col-lg-3">
								<nav class="navbar bg-transparent">
								  <ul class="navbar-nav">
								    <li class="nav-item">
								      <a class="nav-link" href="<?php echo e(asset('/sosial-media/pengaturan')); ?>">Ubah Profil</a>
								    </li>
								    <li class="nav-item">
								      <a class="nav-link active" href="<?php echo e(asset('/sosial-media/pengaturan_pass')); ?>">Ubah Password</a>
								    </li>
								    <li class="nav-item">
								      <a class="nav-link" href="<?php echo e(asset('/sosial-media/pengaturan_notif')); ?>">Notifikasi</a>
								    </li>
								    <?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    <?php if($d->jenis_akun == 'pribadi'): ?>
										    <li class="nav-item">
										      <a class="nav-link" href="<?php echo e(asset('/sosial-media/pengaturan_privasi')); ?>">Privasi dan Keamanan</a>
										    </li>
									    <?php endif; ?>
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								    <li class="nav-item">
								      <a class="nav-link" href="<?php echo e(asset('/sosial-media/pengaturan_log')); ?>">Riwayat Login</a>
								    </li>
								    <li class="nav-item">
								      <a class="nav-link" href="<?php echo e(asset('/sosial-media/pengaturan_hapus_akun')); ?>">Hapus Akun</a>
								    </li>
								  </ul>
								</nav>
							</div>
							<div class="central-meta item col-lg-7">
								<h5 class="f-title" style="margin-bottom: 0px;"><i class="ti-lock"></i> Ubah Password</h5>
								<?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<form action="/sosial-media/ubah_password_proses" method="post" class="form-horizontal">
								<?php echo e(csrf_field()); ?>

									<div style="margin:17px 44px;">
										<input type="hidden" name="id_pengguna" value="<?php echo e($data->id_pengguna); ?>"></input>
									  <!-- <div class="form-group">
									    <label for="staticEmail" class="col-form-label" style="margin-bottom: 15px;">
									    	<img src="<?php echo e(url('/data_file/foto_profil/'.$data->foto_profil)); ?>" alt="" style="height: 50px;width:50px;border-radius:50%;vertical-align:sub;">
									    </label>
									    <div class="col-lg-9">
									      <h6> <?php echo e($data->username); ?> </h6>
									    </div>
									  </div> -->
									  <div class="form-group">
									    <!-- <label for="nama" class="control-label">Password Lama</label><i class="mtrl-select"></i> -->
									    <!-- <div class="col-sm-9"> -->
									      <input type="password" id="pass_lama" name="password_lama">
									      <span class="fa fa-eye field-icon" onclick="myFunction()"></span>
									      <label for="nama" class="control-label">Password Lama</label><i class="mtrl-select"></i>
									    <!-- </div> -->
									  </div>
									  <div class="form-group">
									    <!-- <label for="nama" class="col-sm-3 col-form-label">Password Baru</label> -->
									    <!-- <div class="col-sm-9"> -->
									      <input type="password" class="form-control" id="pass_baru" name="password_baru">
									      <span class="fa fa-eye field-icon" onclick="myFunction2()"></span>
									      <label for="nama" class="control-label">Password Baru</label><i class="mtrl-select"></i>
									    <!-- </div> -->
									  </div>
									  <div class="form-group">
									    <!-- <label for="nama" class="col-sm-3 col-form-label">Konfirmasi Pass.</label> -->
									    <!-- <div class="col-sm-9"> -->
									      <input type="password" class="form-control" id="konfirmasi_pass" name="konfirmasi_password">
									      <span class="fa fa-eye field-icon" onclick="myFunction3()"></span>
									      <label for="nama" class="control-label">Konfirmasi Password Baru</label><i class="mtrl-select"></i>
									    <!-- </div> -->
									  </div>
									  <div class="submit-btns">
									    <!-- <label for="nama" class="col-sm-3 col-form-label"></label> -->
									  	<!-- <div class="col-sm-9"> -->
									      <input class="btn btn-submit" type="submit" id="btnSubmit" value="Ubah Password" style="background-color: #358f66; color: white;"></input>
									  	<!-- </div> -->
									  </div>
									</div>
								</form>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							</div>
						</div>	
					</div>
				</div>
			</div>
		</div>	
	</section>

</div>		
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/pengaturan-password.js')); ?>"></script>
<script type="text/javascript">
	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $('#notif').click(function() {
    	$.ajax({
            url:"<?php echo e(route('sosial-media.update_notif')); ?>",
            type: 'post',
            // dataType: "json",
            data: {
               _token: CSRF_TOKEN
            },
            success: function( data ) {
               	if(document.getElementById("jml_notif")){
               		document.getElementById("jml_notif").style.visibility = "hidden";
               	}
            }
        });
    });
</script>
<script type="text/javascript">
    // CSRF Token
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function(){

      $( "#search" ).autocomplete({
      	appendTo: "#container_search",
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url:"<?php echo e(route('sosial-media.cari_pengguna')); ?>",
            type: 'post',
            dataType: "json",
            data: {
               _token: CSRF_TOKEN,
               search: request.term
            },
            success: function( data ) {
               response( data );
            }
          });
        },
        select: function (event, ui) {
           let username = ui.item.value;
           window.location.href = "http://127.0.0.1:8000/sosial-media/profil/"+username;
           return false;
        }
      })
      .data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	      return $( "<li>" )
	        .append( "<div class='media'><img src='"+item.icon+"' class='align-self-center mr-3' alt='...' style='width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;'> <div class='media-body align-self-center'> <small style='font-weight: 700; color: black; margin-bottom: 0rem;'>"+item.value+"</small><br><small class='mt-0' style='margin-bottom: 0rem; font-weight: 500; color: #989e99;'>"+item.label+"</small>")
	        .appendTo( ul );
	  };

    });
</script>
</body>	

</html>