<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="padding-left: 32px; padding-bottom: 10px; height: 250px; padding-left: 32px; padding-right: 0;">
    
    <div class="carousel-inner">
        <?php $__currentLoopData = $produk_terlaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($loop->iteration == 1 ? 'active' : ''); ?>" data-item="<?php echo e($loop->iteration); ?>">
                <?php
                $foto_produk = json_decode(file_get_contents('https://marketpalcedesaku.masuk.web.id/api/produkgalleri/'.$api['id_produk']), true);
                ?>
                <?php $__currentLoopData = $foto_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api_foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="https://marketpalcedesaku.masuk.web.id/storage/<?php echo e($api_foto['photos']); ?>" class="d-block w-100" style="height: 250px; padding-bottom: 10px; object-fit: cover;">
                    <?php if($loop->iteration == 1): ?>
                    <?php break; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-caption d-none d-md-block">
                    <div class="header-text-carousel">TOP 3 SELLING</div>
                    <div style="margin-bottom: 10px;">
                        <h5 style="display: inline"><a href="https://marketpalcedesaku.masuk.web.id/details/<?php echo e($api['slug']); ?>" target="_blank"><?php echo e($api['name']); ?></a></h5>
                        <small class="badge badge-warning" style="display: inline"><?php echo e($api['jumlah_terjual']); ?> Terjual</small>
                    </div>
                </div>
            </div>
            <?php if($loop->iteration == 3): ?>
            <?php break; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    
</div>