<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Sosial Media Desaku</title>
	<link rel="icon" href="/logo-home.png" type="image/png" sizes="16x16"> 
	    
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('jquery-ui-1.12.1.custom/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slideshow.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/read-less-more.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/halaman-beranda.css')); ?>">
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"> -->

    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/> -->
    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/> -->

</head>
<body id="bodies" style="overflow-y: auto;">
<!--<div class="se-pre-con"></div>-->
<div class="theme-layout">
	
	
	<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
		<?php echo $__env->make('theme.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</nav>
		
	<section>
		<div class="gap gray-bg" style="padding-top: 100px;">
			<div class="container-fluid">
				<?php if(Session::get('success')): ?>
					<div class="alert alert-success">
						<?php echo e(Session::get('success')); ?>

						<button type="button" class="close" data-dismiss="alert">&times;</button>
					</div>
				<?php endif; ?>
				<div class="row" style="padding-bottom: 10px; height: 250px;">
					<div class="col" style="height: 250px; padding-bottom: 10px;">
						<?php echo $__env->make('theme.produk_terlaris', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
					<div class="col" style="height: 250px; padding-bottom: 10px;">
						<?php echo $__env->make('theme.wisata', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="row" id="page-contents">
							<div class="col-lg-3">
								<aside class="sidebar static">
									<div class="widget static-widget" style="margin-bottom: 10px;">
										<h4 class="widget-title" style="margin-bottom: 0; padding: 10px 20px;">Posting 
											<i class="ti-pencil-alt" onclick="newpost()" id="new-post" style="float: right"></i>
										</h4>
									</div>
									<div class="widget static-widget">
										<h4 class="widget-title">Rekomendasi Desa</h4>
										<ul class="followers">
										<?php if($rekomendasi != NULL): ?>
	                                        <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li>
													<figure><img src="<?php echo e(url('/data_file/'.$rek->username.'/foto_profil/'.$rek->foto_profil)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;"></figure>
													<div class="friend-meta">
														<h4><a href="/sosial-media/profil/<?php echo e($rek->username); ?>" title=""><?php echo e($rek->nama); ?></a></h4>
														<a href="/sosial-media/tambah_teman/<?php echo e($rek->username); ?>" title="" class="underline">Follow</a>
													</div>
												</li>
	                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                    <?php else: ?>
											<li>
												<div align="center">Tidak Ada Rekomendasi Desa</div>
											</li>
										<?php endif; ?>
										</ul>
									</div><!-- who's following -->
									<div class="widget static-widget">
										<h4 class="widget-title">Rekomendasi Teman</h4>
										<ul class="followers">
										<?php if($rekomendasi_teman != NULL): ?>
	                                        <?php $__currentLoopData = $rekomendasi_teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rek_tmn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li>
													<figure><img src="<?php echo e(url('/data_file/'.$rek_tmn->username.'/foto_profil/'.$rek_tmn->foto_profil)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;"></figure>
													<div class="friend-meta">
														<h4><a href="/sosial-media/profil/<?php echo e($rek_tmn->username); ?>" title=""><?php echo e($rek_tmn->nama); ?></a></h4>
														<a href="/sosial-media/tambah_teman/<?php echo e($rek_tmn->username); ?>" title="" class="underline">Tambah Teman</a>
													</div>
												</li>
	                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                    <?php else: ?>
											<li>
												<div align="center">Tidak Ada Rekomendasi Teman</div>
											</li>
										<?php endif; ?>
										</ul>
									</div>
									<div class="widget static-widget">
										<h4 class="widget-title">Group</h4>
										<div id="searchDir2"></div>
										<ul id="people-list2" class="friendz-list" style="max-height: 200px;">
											<?php if($list_all_group): ?>
		                                        <?php $__currentLoopData = $list_all_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<figure>
															<img src="<?php echo e(url('/data_file/group/'.$grup->nama_group.'/foto_sampul/'.$grup->foto_sampul_group)); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover;">
														</figure>
														<div class="friend-meta">
															<h4><a href="/sosial-media/halaman_group_detail/<?php echo e($grup->id_group); ?>" title=""><?php echo e($grup->nama_group); ?></a></h4>
														</div>
													</li>
		                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                                    <?php else: ?>
		                                    	<li>
													<div align="center">Tidak Ada Group Terdaftar</div>
												</li>
		                                    <?php endif; ?>
										</ul>
									</div>
									<div class="widget friend-list stick-widget">
										<h4 class="widget-title">Infrastruktur Desa</h4>
										<ul class="friendz-list">
										<?php if($api_infra != NULL): ?>
											<?php $__currentLoopData = $api_infra['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<figure style="width:100%; margin-bottom: 5px;">
													<img src="<?php echo e($api['foto']); ?>" alt="" style="width: 100%; height: 75px; border-radius: 0;">
												</figure>
												<div class="friendz-meta" style="padding-left: 0;">
													<a href="<?php echo e($api['url']); ?>" target="_blank"><b><?php echo e($api['nama']); ?></b></a>
													<small style="text-transform: capitalize; display: inline"><?php echo e(strtolower($api['desa'])); ?></small> <small class="<?php echo e($api['Status'] == 'nonMusrenbang' ? 'badge badge-warning' : 'badge badge-success'); ?>" style="display: inline;"><?php echo e($api['Status']); ?></small>
												</div>
											</li>
											<?php if($loop->iteration == 3): ?>
											<?php break; ?>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
										<?php else: ?>
											<li>
												<div align="center">Tidak Ada Infrastruktur Terbaru</div>
											</li>
										<?php endif; ?>
										</ul>
									</div>
								</aside>
							</div><!-- sidebar -->
							<br>
							<div class="col-lg-6">
								<div class="central-meta" id="postbox">
									<div class="new-postbox">
										<figure>
											<img src="<?php echo e(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil)); ?>" style="width: 60px; height: 60px;">
										</figure>
										<div class="newpst-input">
											<form method="post" action="/sosial-media/post" enctype="multipart/form-data">
											<?php echo e(csrf_field()); ?>

												<div class="form-group">
													<input type="text" name="tempat" id="tempat" style="border:1px solid #eeeeee; background-color: white; padding: 10px;" placeholder="Pilih Lokasi" required/>
													<input type="hidden" id="long" name="longitude_tempat">
													<input type="hidden" id="lat" name="latitude_tempat">
												</div>
												<textarea rows="3" name="caption" onkeyup="countChars(this);" placeholder="write something" id="caption_post" maxlength="500" required></textarea>
												<div class="attachments">
													<ul>
														<li><small id="charNum" style="margin:0;">500/500</small></li>
														<li>
															<i class="fa fa-image"></i>
															<label class="fileContainer">
																<input type="file" name="file_foto[]" id="pro-image" required multiple> <!-- id="pro-image" -->
															</label>
														</li>
														<li>
															<button type="submit">Post</button>
														</li>
													</ul>
												</div>
											</form>
											<!-- <span id="error-message-capt" class="validation-error-label"></span> -->
											<span id="error-message" class="validation-error-label"></span>
											<div class="preview-images-zone">
											</div>
										</div>
									</div>
								</div><!-- add post new box -->
								<div id="map"></div>
								<!-- include ke beranda before / two page -->
								<?php echo $__env->make('theme.two_page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div><!-- centerl meta -->
							<div class="col-lg-3">
								<aside class="sidebar static">
									<?php if(auth()->user()->pengguna->jenis_akun == 'desa'): ?>
									<div class="widget">
										<h4 class="widget-title">Your page</h4>	
										<div class="your-page">
											<figure>
												<img src="<?php echo e(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil)); ?>" style="width: 50px; height: 50px;">
											</figure>
											<div class="page-meta">
												<a href="/sosial-media/profil/<?php echo e(auth()->user()->pengguna->username); ?>" title="" class="underline">My page</a>
												<span>
													<i class="ti-user" style="vertical-align: unset"></i>
													<?php $__currentLoopData = $jml_konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jml): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<a href="insight.html" title="">Post <em><?php echo e($jml->jml_konten); ?></em></a>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</span>
												<!-- <span><i class="ti-user"></i><a href="insight.html" title="">Following <em>2</em></a></span> -->
											</div>
											<div class="page-likes">
												<ul class="nav nav-tabs likes-btn">
													<li class="nav-item"><a class="active" href="#link1" data-toggle="tab">likes</a></li>
													 <li class="nav-item"><a class="" href="#link2" data-toggle="tab">Followers</a></li>
												</ul>
												<!-- Tab panes -->
												<div class="tab-content">
												  	<div class="tab-pane active fade show " id="link1" >
												  		<?php $__currentLoopData = $data_likes_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_likes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<span><i class="ti-heart"></i><?php echo e(number_format($dt_likes->jml_likes)); ?></span>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php $__currentLoopData = $data_likes_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_likes_week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														  	<?php if($dt_likes_week->jml_likes !== 0): ?>
														  		<a href="#" title="weekly-likes"><?php echo e(number_format($dt_likes_week->jml_likes)); ?> like baru minggu ini</a>
														  	<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												  	</div>
												  	<div class="tab-pane fade" id="link2" >
													  	<?php $__currentLoopData = $data_followers_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_followers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														  	<span><i class="ti-user"></i><?php echo e(number_format($dt_followers->jml)); ?></span>
													  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													  	<?php $__currentLoopData = $data_followers_week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_followers_week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														  	<?php if($dt_followers_week->jml !== 0): ?>
														  		<a href="#" title="weekly-likes"><?php echo e(number_format($dt_followers_week->jml)); ?> Followers Baru Minggu Ini</a>
														  	<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												  	</div>
												</div>
											</div>
										</div>
									</div><!-- page like widget -->
									<?php endif; ?>
									<!-- <div class="widget friend-list stick-widget"> -->
									<div class="widget friend-list">
										<h4 class="widget-title">Berita Desa Terbaru</h4>
										<ul class="friendz-list">
										<?php if($api_berita != NULL): ?>
											<?php $__currentLoopData = $api_berita['articles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li>
													<figure style="width:100%; margin-bottom: 5px;">
														<img src="<?php echo e($api['urlToImage']); ?>" alt="" style="width: 100%; height: 75px; border-radius: 0;">
													</figure>
													<div class="friendz-meta" style="padding-left: 0;">
														<a href="<?php echo e($api['url']); ?> "><b><?php echo e($api['title']); ?></b></a>
														<small style="text-transform: capitalize;"><?php echo e(strtolower($api['source']['name'])); ?> - <?php echo e(date_format(date_create($api['publishedAt']), "d M 'y")); ?></small>
													</div>
												</li>
												<?php if($loop->iteration == 3): ?>
												<?php break; ?>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
											<li>
												<div align="center">Tidak Ada Berita Terbaru</div>
											</li>
										<?php endif; ?>
										</ul>
									</div>
									<div class="widget friend-list stick-widget">
										<h4 class="widget-title">Video Desa Terbaru</h4>
										<ul class="friendz-list">
										<?php if($api_video != NULL): ?>
											<?php $__currentLoopData = $api_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<figure style="width:100%; margin-bottom: 5px;">
													<img src="https://desatube.masuk.web.id<?php echo e($api['thumbnail']); ?>" alt="" style="width: 100%; height: 75px; border-radius: 0;">
												</figure>
												<div class="friendz-meta" style="padding-left: 0;">
													<a href="https://desatube.masuk.web.id/watch/<?php echo e($api['uid']); ?>" target="_blank"><b><?php echo e($api['title']); ?></b></a>
													<small style="text-transform: capitalize;"><?php echo e(strtolower($api['village_name'])); ?> - <?php echo e(date_format(date_create($api['created_at']), "d M 'y")); ?></small>
												</div>
											</li>
											<?php if($loop->iteration == 3): ?>
											<?php break; ?>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
										<?php else: ?>
											<li>
												<div align="center">Tidak Ada Video Terbaru</div>
											</li>
										<?php endif; ?>
										</ul>
									</div><!-- friends list sidebar -->
								</aside>
							</div><!-- sidebar -->
						</div>	
					</div>
				</div>
			</div>
		</div>	
	</section>

</div>		
<div class="modal fade" id="modalReport" role="dialog">
    <div class="modal-dialog modal-sm" style="max-width: 600px;">
        <form method="post" action="/sosial-media/report_proses" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Report <span class="kategori_report"></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Alasan Pelaporan <span class="kategori_report"></span></label>
                        <select class="form-control" id="alasan_report" name="alasan_report">
                            <option selected disabled>Pilih Alasan</option>
                            <option value="Spam">Spam</option>
                            <option value="Ujaran / Simbol Kebencian">Ujaran / Simbol Kebencian</option>
                            <option value="Ketelanjangan / Aktivitas Seksual">Ketelanjangan / Aktivitas Seksual</option>
                            <option value="Kekerasan / Organisasi Berbahaya">Kekerasan / Organisasi Berbahaya</option>
                            <option value="Penipuan">Penipuan</option>
                            <option value="Informasi Palsu">Informasi Palsu</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="kategori" name="kategori_report" value=""/>
                    <input type="hidden" name="acct_reporter" value="<?php echo e(Auth::user()->pengguna->id_pengguna); ?>"/>
                    <input type="hidden" id="reported" name="id_reported" value=""/>
                    <input class="btn btn-sm btn-submit" type="submit" style="background-color: red; color: white;" value="Report"></input>
                </div>
            </div>
        </form>
    </div>
</div>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/read-less-more.js')); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- <script src="<?php echo e(asset('assets/js/jquery-2.1.4.min.js')); ?>"></script> -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slideshow.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-iHgzDAzd_uS3biSkqVRw_sxAoqS1o04&libraries=places&callback=initMap" async defer></script>
<script type="text/javascript" src="<?php echo e(asset('slick-1.8.1/slick/slick.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/halaman-beranda.js')); ?>"></script>
<script>
// var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
// $('#notif').click(function () {
//     $.ajax({
//         url: "<?php echo e(route('sosial-media.update_notif')); ?>",
//         type: 'post',
//         // dataType: "json",
//         data: {
//             _token: CSRF_TOKEN
//         },
//         success: function (data) {
//             if (document.getElementById("jml_notif")) {
//                 document.getElementById("jml_notif").style.visibility = "hidden";
//             }
//         }
//     });
// });

// CSRF Token
var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
$(document).ready(function () {
    $("#search").autocomplete({
		appendTo: "#container_search",
		source: function (request, response) {
			// Fetch data
			$.ajax({
				url: "<?php echo e(route('sosial-media.cari_pengguna')); ?>",
				type: 'post',
				dataType: "json",
				data: {
					_token: CSRF_TOKEN,
					search: request.term
				},
				success: function (data) {
					response(data);
				}
			});
		},
		select: function (event, ui) {
			let username = ui.item.value;
			window.location.href = window.location.origin + "/sosial-media/profil/" + username;
			return false;
		}
	})
	.data("ui-autocomplete")._renderItem = function (ul, item) {
		return $("<li>")
			.append("<div class='media'><img src='" + item.icon + "' class='align-self-center mr-3' alt='...' style='width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;'> <div class='media-body align-self-center'> <small style='font-weight: 700; color: black; margin-bottom: 0rem;'>" + item.value + "</small><br><small class='mt-0' style='margin-bottom: 0rem; font-weight: 500; color: #989e99;'>" + item.label + "</small>")
			.appendTo(ul);
	};
});
</script>

</body>	

</html>