<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Sosial Media Desaku</title>
	<link rel="icon" href="/logo-home.png" type="image/png" sizes="16x16"> 
	
    
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick-1.8.1/slick/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('jquery-ui-1.12.1.custom/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slideshow.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/read-less-more.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/profil.css')); ?>">

</head>
<body>
<!--<div class="se-pre-con"></div>-->
<div class="theme-layout">
	
	<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
		<?php echo $__env->make('theme.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</nav>
    
    <section>
    	<?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="feature-photo">
			<figure class="img_sampul">
				<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_sampul/'.$data->foto_sampul)); ?>" id="img_sampul" alt="" style="width: 1366px; height: 200px;">
			</figure>
			<?php if(Auth::check()): ?>
				<?php if($data->username == auth()->user()->pengguna->username): ?>
				<form class="edit-phto" style="bottom: 120px;" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

					<i class="fa fa-camera-retro"></i>
					<label class="fileContainer">
						Ubah Foto Sampul
						<input type="file" name="foto_sampul" id="sampul"/>
						<input type="hidden" name="id_pengguna" value="<?php echo e($data->id_pengguna); ?>" class="id_pengguna"/>
						<input type="hidden" name="username_pengguna" value="<?php echo e($data->username); ?>" class="uname_pengguna"/>
					</label>
				</form>
				<?php endif; ?>
			<?php endif; ?>
			<div class="container-fluid">
				<div class="row merged">
					<div class="col-lg-5 col-sm-4"></div>
					<div class="col-lg-2 col-sm-3">
						<div class="user-avatar">
							<figure class="img_profil">
								<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_profil/'.$data->foto_profil)); ?>" id="img_profil" alt="">
								<?php if(Auth::check()): ?>
									<?php if($data->username == auth()->user()->pengguna->username): ?>
									<form class="edit-phto" enctype="multipart/form-data">
									<?php echo e(csrf_field()); ?>

										<i class="fa fa-camera-retro"></i>
										<label class="fileContainer">
											Ubah Foto Profil
											<input type="file" name="foto_profil" id="profil"/>
											<input type="hidden" name="id_pengguna" value="<?php echo e($data->id_pengguna); ?>" class="id_pengguna"/>
											<input type="hidden" name="username_pengguna" value="<?php echo e($data->username); ?>" class="uname_pengguna"/>
										</label>
									</form>
									<?php endif; ?>
								<?php endif; ?>
							</figure>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</section>
	<?php $array = array();
		if(Auth::check()){
			foreach($follow_request as $req){
				$array[] = $req->id_pengguna;
			}
		}

		$arr_flw = array();
		if(Auth::check()){
			foreach ($followers_saya as $flw) {
				$arr_flw[] = $flw->username;
			}
		}

		$arr_flwing = array();
		if(Auth::check()){
			foreach ($teman_saya as $tmn_sy) {
				$arr_flwing[] = $tmn_sy->username;
			}
		}
		// print_r($arr_flwing);die;
	?>
	<section style="background-color: #f4f2f2;">
		<div style="padding-top:15px; text-align:center; color: #000;">
			<div class="col-lg-1"></div>
			<div class="central-meta col-lg-10" style="text-align: left;">
				<?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<h3><?php echo e($d->nama); ?> <small class="text-muted" style="font-size: 14px;"><?php echo e('@'.$d->username); ?></small></h3>
					<p style="color: black;"><?php echo e($d->bio); ?></p>
					<div>
						<?php if($d->marketplace): ?>
							<a href="<?php echo e($d->marketplace); ?>" target="_blank" style="color:blue;" data-toggle="tooltip" title="<?php echo e($d->jenis_akun == 'desa' ? 'Desastore' : 'Marketplace'); ?>"><i class="ti-shopping-cart" style="padding: 5px; border: 1px solid; border-radius: 3px;"></i></a>
						<?php endif; ?>
						<?php if($d->youtube): ?>
							<a href="<?php echo e($d->youtube); ?>" target="_blank" style="color:blue;" data-toggle="tooltip" title="<?php echo e($d->jenis_akun == 'desa' ? 'Desatube' : 'Youtube'); ?>"><i class="ti-video-camera" style="padding: 5px; border: 1px solid; border-radius: 3px;"></i></a>
						<?php endif; ?>
						<?php if($d->website): ?>
							<a href="<?php echo e($d->website); ?>" target="_blank" style="color:blue;" data-toggle="tooltip" title="<?php echo e($d->jenis_akun == 'desa' ? 'Desatour' : 'Website'); ?>"><i class="ti-gallery" style="padding: 5px; border: 1px solid; border-radius: 3px;"></i></a>
						<?php endif; ?>
						<?php if($d->berita): ?>
							<a href="<?php echo e($d->berita); ?>" target="_blank" style="color:blue;" data-toggle="tooltip" title="Desanews"><i class="ti-announcement" style="padding: 5px; border: 1px solid; border-radius: 3px;"></i></a>
						<?php endif; ?>
						<!-- <?php if($d->musrembang): ?>
							<a href="<?php echo e($d->musrembang); ?>" target="_blank" style="color:blue;"><i class="ti-agenda" style="padding: 5px; border: 1px solid; border-radius: 3px;"></i></a>
						<?php endif; ?> -->
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php if(Auth::check()): ?>
					<?php if($d->username != auth()->user()->pengguna->username): ?>
						<!-- <br> -->
						<div style="position: absolute; right: 0; top: 0; padding-right: 25px; padding-top: 25px;">
							<a href="#" onclick="cek_chat('<?php echo e(url('/data_file/'.$d->username.'/foto_profil/'.$d->foto_profil)); ?>', '<?php echo e($d->username); ?>', '<?php echo e(auth()->user()->pengguna->id_pengguna); ?>', '<?php echo e(auth()->user()->pengguna->username); ?>')" class="btn btn-outline-secondary btn-sm" role="button" style="position: relative; border: 1px solid;">Pesan</a>
							<?php if(!in_array($d->id_pengguna, $array)): ?>
								<?php if(in_array($d->username, $arr_flwing)): ?>
									<!-- <a href="" role="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#myModalUnfollow<?php echo e($d->username); ?>" style="position: relative; border: 1px solid;">Following</a> -->
									<a onclick="modalUnfollow('<?php echo e($d->id_pengguna); ?>', '<?php echo e($d->username); ?>', '<?php echo e($d->foto_profil); ?>')" href="#" role="button" class="btn btn-outline-success btn-sm" style="position: relative; border: 1px solid;">Following</a>
								<?php elseif(in_array($d->username, $arr_flw)): ?>
										<a href="/sosial-media/tambah_teman2/<?php echo e($d->username); ?>" role="button" class="btn btn-success btn-sm" style="position: relative; border: 1px solid #28a745;">Follow Back</a>
								<?php else: ?>
									<a href="/sosial-media/tambah_teman2/<?php echo e($d->username); ?>" role="button" class="btn btn-success btn-sm" style="position: relative; border: 1px solid #28a745;">Follow</a>
								<?php endif; ?>
								<!-- <div class="modal fade" id="myModalUnfollow<?php echo e($d->username); ?>" role="dialog">
									<div class="modal-dialog modal-sm" style="max-width: 400px;">
										<div class="modal-content">
											<div class="modal-content" style="text-align: center;">
											<ul class="list-group list-group-flush">
												<li class="list-group-item" style="padding-top: 20px;">
													<img src="<?php echo e(url('/data_file/foto_profil/'.$d->foto_profil)); ?>" style="border-radius: 50%; width: 20%; height: 70px;"><br><br>
													<span>Berhenti mengikuti <?php echo e('@'.$data->username); ?>?</span><br>
													<small><?php echo e($d->username); ?> tidak akan mengetahui bahwa Anda telah berhenti mengikutinya.</small>
												</li>
												<li class="list-group-item"><a onclick="if(!confirm('Anda yakin ingin berhenti mengikuti akun ini?')) return false;" href="/sosial-media/hapus_following/<?php echo e($d->username); ?>" style="font-weight: 600; color: red;"> Berhenti Mengikuti </a></li>
												<li class="list-group-item"><a href="" data-dismiss="modal"> Batalkan </a></li>
											</ul>
										</div>
										</div>
									</div>
								</div> -->
							<?php else: ?>
								<a href="/sosial-media/batal_request/<?php echo e($req->id); ?>" role="button" class="btn btn-success btn-sm" style="position: relative; border: 1px solid #28a745;">Requested</a>
							<?php endif; ?>
							<button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#myModalMore" style="position: relative;"><i class="fa fa-ellipsis-h"></i></button>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			</div>
			<div class="col-lg-1"></div>
			<div class="col-lg-1"></div>
			<div class="central-meta col-lg-10" style="margin-bottom: 0px; border-bottom-right-radius: 0; border-bottom-left-radius: 0; border-bottom: 0px none;">
				<div>
					<?php foreach($pengaturan as $p){
							$pengaturan_akun = $p->akun_privat;
					} ?>
					<?php $__currentLoopData = $jml_konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a data-ripple="" style="padding:15px"><b><?php echo e($data->jml_konten); ?></b> Post</a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $jml_followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($pengaturan_akun == 'tidak'): ?>
							<a <?php if(Auth::check()) { echo 'href="#" data-toggle="modal" data-target="#myModalFollowers" data-ripple=""'; } ?> style="padding:15px"><b><?php echo e($d3->jml_followers); ?></b> Followers</a>
						<?php else: ?>
							<?php if(Auth::check()): ?>
								<?php if($p->id_pengguna == auth()->user()->pengguna->id_pengguna): ?>
									<a <?php if(Auth::check()) { echo 'href="#" data-toggle="modal" data-target="#myModalFollowers" data-ripple=""'; } ?> style="padding:15px"><b><?php echo e($d3->jml_followers); ?></b> Followers</a>
								<?php elseif(in_array($d->username, $arr_flwing)): ?>
									<a <?php if(Auth::check()) { echo 'href="#" data-toggle="modal" data-target="#myModalFollowers" data-ripple=""'; } ?> style="padding:15px"><b><?php echo e($d3->jml_followers); ?></b> Followers</a>
								<?php else: ?>
									<a style="padding:15px"><b><?php echo e($d3->jml_followers); ?></b> Followers</a>
								<?php endif; ?>
							<?php else: ?>
								<a style="padding:15px"><b><?php echo e($d3->jml_followers); ?></b> Followers</a>
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $jml_teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($pengaturan_akun == 'tidak'): ?>
							<a  <?php if(Auth::check()) { echo 'href="#" data-toggle="modal" data-target="#myModalFollowing" data-ripple=""'; } ?> style="padding:15px"><b><?php echo e($d2->jml_following); ?></b> Following</a>
						<?php else: ?>
							<?php if(Auth::check()): ?>
								<?php if($p->id_pengguna == auth()->user()->pengguna->id_pengguna): ?>
									<a  <?php if(Auth::check()) { echo 'href="#" data-toggle="modal" data-target="#myModalFollowing" data-ripple=""'; } ?> style="padding:15px"><b><?php echo e($d2->jml_following); ?></b> Following</a>
								<?php elseif(in_array($d->username, $arr_flwing)): ?>
									<a  <?php if(Auth::check()) { echo 'href="#" data-toggle="modal" data-target="#myModalFollowing" data-ripple=""'; } ?> style="padding:15px"><b><?php echo e($d2->jml_following); ?></b> Following</a>
								<?php else: ?>
									<a style="padding:15px"><b><?php echo e($d2->jml_following); ?></b> Following</a>
								<?php endif; ?>
							<?php else: ?>
								<a style="padding:15px"><b><?php echo e($d2->jml_following); ?></b> Following</a>
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<?php if($d->marketplace): ?>
			<div class="central-meta col-lg-10" style="padding: 0; border-top-right-radius: 0; border-top-left-radius: 0;">
				<ul class="nav nav-tabs nav-pills nav-fill" style="padding: 5px;">
					<li class="nav-item">
						<a class="active" href="#link1" data-toggle="tab" style="font-size: 15px; font-weight: bold; display: block;">Post</a>
					</li>
					<li class="nav-item">
						<a class="" href="#link2" data-toggle="tab" style="font-size: 15px; font-weight: bold; display: block;">Shop</a>
					</li>
				</ul>
			</div>
			<!-- Tab panes -->
			<div class="tab-content">
			  	<div class="tab-pane active fade show " id="link1" >
			  		<?php echo $__env->make('theme.postingan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			  	</div>
			  	<div class="tab-pane fade" id="link2" >
				  	<?php echo $__env->make('theme.shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			  	</div>
			</div>
			<?php else: ?>
				<br>
				<br>
				<?php echo $__env->make('theme.postingan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php endif; ?>
		</div>
		<div class="col-lg-4 col-sm-4"></div>
	</section>

	<?php if(Auth::check()): ?>
		<div class="modal fade" id="myModalFollowers" role="dialog">
			<div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 500px;">
				<div class="modal-content">
					<div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
						<h6 class="modal-title">Followers</h6>
					</div>
					<ul class="list-group list-group-flush">
						<div class="input-group flex-nowrap" id="cari_teman2">
							<div class="input-group-prepend">
								<span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
									Cari: 
								</span>
							</div>
							<div id="kolom_input_cari2" style="width: 100%;"></div>
						</div>
						<div class="list-group list-group-flush" style="overflow-y: auto; max-height: 315px;" id="teman_yang_dicari2">
							<?php if($followers != NULL): ?>
								<?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a class="list-group-item list-group-item-action">
										<div class="media">
											<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_profil/'.$data->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
											<div class="media-body align-self-center">
												<small onclick="lihatProfil('<?php echo e($data->username); ?>')" target="_blank" style="cursor: pointer; font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data->username); ?></small><br>
												<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data->nama); ?></small>
											</div>
											<?php if(Auth::check()): ?>
												<?php if($d->username != auth()->user()->pengguna->username): ?>
													<?php if($data->username != auth()->user()->pengguna->username): ?>
														<?php if($d->username == auth()->user()->pengguna->username): ?>
															<!-- <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#hapusFollowers<?php echo e($data->username); ?>" style="position: relative; top:10px; margin-top: 10px;">Remove</button> -->
															<button type="button" class="btn btn-outline-danger btn-sm" onclick="hapusFollowers('<?php echo e($data->id_pengguna); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->foto_profil); ?>')" style="position: relative; margin-top: 10px;">Remove</button>
														<?php endif; ?>
														<form method="GET" action="/sosial-media/tambah_teman2/<?php echo e($data->username); ?>">
														<?php if(in_array($data->username, $arr_flwing)): ?>
															<?php if(!in_array($data->id_pengguna, $array)): ?>
																<?php if(in_array($data->username, $arr_flwing)): ?>
																	<!-- <button type="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#myModalUnfollow2<?php echo e($data->username); ?>" style="position: relative; top:10px;">Following</button> -->
																	<button type="button" class="btn btn-outline-success btn-sm" onclick="modalUnfollow('<?php echo e($data->id_pengguna); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->foto_profil); ?>')" style="position: relative; top:10px;">Following</button>
																<?php elseif(in_array($data->username, $arr_flw)): ?>
																	<button type="button" href="/sosial-media/tambah_teman2/<?php echo e($data->username); ?>" class="btn btn-success btn-sm" style="position: relative; top:10px; margin-left: 5px; margin-top: 10px;">Follow Back</button>
																<?php else: ?>
																	<button type="submit" class="btn btn-success btn-sm" style="position: relative; margin-top: 10px;">Follow</button>
																<?php endif; ?>
															<?php else: ?>
																<button onclick="window.location.href='/sosial-media/batal_request/<?php echo e($req->id); ?>'" type="button" class="btn btn-success btn-sm" style="position: relative; border: 1px solid #28a745; margin-top: 10px;">Requested</button>
															<?php endif; ?>
														<?php else: ?>
															<button type="submit" class="btn btn-success btn-sm" style="position: relative; margin-top: 10px;">Follow</button>
														<?php endif; ?>
														</form>
													<?php endif; ?>
												<?php else: ?>			
													<?php if(in_array($data->username, $arr_flwing)): ?>
														<?php if($d->username == auth()->user()->pengguna->username): ?>
															<!-- <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#hapusFollowers<?php echo e($data->username); ?>" style="position: relative; margin-top: 10px;">Remove</button> -->
															<button type="button" class="btn btn-outline-danger btn-sm" onclick="hapusFollowers('<?php echo e($data->id_pengguna); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->foto_profil); ?>')" style="position: relative; margin-top: 10px;">Remove</button>
														<?php endif; ?>
													<?php elseif(in_array($data->username, $arr_flw)): ?>
															<form method="GET" action="/sosial-media/tambah_teman2/<?php echo e($data->username); ?>">
																<?php echo e(csrf_field()); ?>

																<?php if($d->username == auth()->user()->pengguna->username): ?>
																	<!-- <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#hapusFollowers<?php echo e($data->username); ?>" style="position: relative; margin-top: 10px;">Remove</button> -->
																	<button type="button" class="btn btn-outline-danger btn-sm" onclick="hapusFollowers('<?php echo e($data->id_pengguna); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->foto_profil); ?>')" style="position: relative; margin-top: 10px;">Remove</button>
																<?php endif; ?>
																<?php if(!in_array($data->id_pengguna, $array)): ?>
																	<button type="submit" class="btn btn-success btn-sm" style="position: relative; margin-top: 10px;">Follow Back</button>
																<?php else: ?>
																	<button onclick="window.location.href='/sosial-media/batal_request/<?php echo e($req->id); ?>'" type="button" class="btn btn-success btn-sm" style="position: relative; border: 1px solid #28a745; margin-top: 10px;">Requested</button>
																<?php endif; ?>
															</form>
													<?php else: ?>
														<form method="GET" action="/sosial-media/tambah_teman2/<?php echo e($data->username); ?>">
															<?php echo e(csrf_field()); ?>

															<!-- <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#hapusFollowers<?php echo e($data->username); ?>" style="position: relative; margin-top: 10px;">Remove</button> -->
															<button type="button" class="btn btn-outline-danger btn-sm" onclick="hapusFollowers('<?php echo e($data->id_pengguna); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->foto_profil); ?>')" style="position: relative; margin-top: 10px;">Remove</button>
															<?php if(!in_array($data->id_pengguna, $array)): ?>
																<button type="submit" class="btn btn-success btn-sm" style="position: relative; margin-top: 10px;">Follow</button>
															<?php else: ?>
																<button onclick="window.location.href='/sosial-media/batal_request/<?php echo e($req->id); ?>'" type="button" class="btn btn-success btn-sm" style="position: relative; border: 1px solid #28a745; margin-top: 10px;">Requested</button>
															<?php endif; ?>
														</form>
													<?php endif; ?>
												<?php endif; ?>
											<?php endif; ?>
										</div>
									</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
							<?php else: ?>
								<br>
								<p style="text-align: center; color: black;">Tidak Ada Teman</p>
							<?php endif; ?>
						</div>
					</ul>
				</div>
			</div>
		</div>
	<?php endif; ?>
	
	<?php if(Auth::check()): ?>
		<div class="modal fade" id="myModalFollowing" role="dialog">
			<div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 500px;">
				<div class="modal-content">
					<div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
						<h6 class="modal-title">Following</h6>
					</div>
					<ul class="list-group list-group-flush">
							<div class="input-group flex-nowrap" id="cari_teman">
								<div class="input-group-prepend">
									<span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
										Cari: 
									</span>
								</div>
								<div id="kolom_input_cari" style="width: 100%;"></div>
							</div>
							<div class="list-group list-group-flush" style="overflow-y: auto; max-height: 315px;" id="teman_yang_dicari">
							<?php if($teman != NULL): ?>
								<?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a class="list-group-item list-group-item-action">
										<div class="media">
											<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_profil/'.$data->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
											<div class="media-body align-self-center">
												<small onclick="lihatProfil('<?php echo e($data->username); ?>')" style="cursor: pointer;font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data->username); ?></small><br>
												<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data->nama); ?></small>
											</div>
											<?php if($d->username == auth()->user()->pengguna->username): ?>
												<?php if($data->username != auth()->user()->pengguna->username): ?>
													<!-- <button type="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#myModalUnfollow2<?php echo e($data->username); ?>" style="position: relative; top:10px;">Following</button> -->
													<button type="button" class="btn btn-outline-success btn-sm" onclick="modalUnfollow('<?php echo e($data->id_pengguna); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->foto_profil); ?>')" style="position: relative; top:10px;">Following</button>
												<?php endif; ?>
											<?php else: ?>
												<?php if($data->username != auth()->user()->pengguna->username): ?>
												<?php if(!in_array($data->id_pengguna, $array)): ?>
													<?php if(in_array($data->username, $arr_flwing)): ?>
														<!-- <button type="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#myModalUnfollow2<?php echo e($data->username); ?>" style="position: relative; top:10px;">Following</button> -->
														<button type="button" class="btn btn-outline-success btn-sm" onclick="modalUnfollow('<?php echo e($data->id_pengguna); ?>', '<?php echo e($data->username); ?>', '<?php echo e($data->foto_profil); ?>')" style="position: relative; top:10px;">Following</button>
													<?php elseif(!in_array($data->username, $arr_flwing) AND in_array($data->username, $arr_flw)): ?>
														<button type="button" href="/sosial-media/tambah_teman2/<?php echo e($data->username); ?>" class="btn btn-success btn-sm" style="position: relative; top:10px; margin-left: 5px; margin-top: 10px;">Follow Back</button>
													<?php else: ?>
														<form method="GET" action="/sosial-media/tambah_teman2/<?php echo e($data->username); ?>">
															<button type="submit" class="btn btn-success btn-sm" style="position: relative; margin-top: 10px;">Follow</button>
														</form>
													<?php endif; ?>
												<?php else: ?>
													<button onclick="window.location.href='/sosial-media/batal_request/<?php echo e($req->id); ?>'" type="button" class="btn btn-success btn-sm" style="position: relative; border: 1px solid #28a745; margin-top: 10px;">Requested</button>
												<?php endif; ?>
												<?php endif; ?>
											<?php endif; ?>
										</div>
									</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
							<?php else: ?>
								<br>
								<p style="text-align: center; color: black;">Tidak Ada Teman</p>
							<?php endif; ?>
							</div>
					</ul>
				</div>
			</div>
		</div>
	<?php endif; ?>

</div>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/read-less-more.js')); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slideshow.js')); ?>"></script>
<script src="<?php echo e(asset('js/profil.js')); ?>"></script>
<script type="text/javascript">
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    // $('#notif').click(function() {
    // 	$.ajax({
    //         url:"<?php echo e(route('sosial-media.update_notif')); ?>",
    //         type: 'post',
    //         // dataType: "json",
    //         data: {
    //            _token: CSRF_TOKEN
    //         },
    //         success: function( data ) {
    //            	if(document.getElementById("jml_notif")){
    //            		document.getElementById("jml_notif").style.visibility = "hidden";
    //            	}
    //         }
    //     });
    // });
</script>
<script type="text/javascript" src="<?php echo e(asset('slick-1.8.1/slick/slick.min.js')); ?>"></script>
<script type="text/javascript">

    // CSRF Token
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function(){

      $( "#search" ).autocomplete({
      	appendTo: "#container_search",
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url:"<?php echo e(route('sosial-media.cari_pengguna')); ?>",
            type: 'post',
            dataType: "json",
            data: {
               _token: CSRF_TOKEN,
               search: request.term
            },
            success: function( data ) {
               response( data );
            }
          });
        },
        select: function (event, ui) {
           let username = ui.item.value;
           window.location.href = window.location.origin+"/sosial-media/profil/"+username;
           return false;
        }
      })
      .data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	      return $( "<li>" )
	        .append( "<div class='media'><img src='"+item.icon+"' class='align-self-center mr-3' alt='...' style='width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;'> <div class='media-body align-self-center'> <small style='font-weight: 700; color: black; margin-bottom: 0rem;'>"+item.value+"</small><br><small class='mt-0' style='margin-bottom: 0rem; font-weight: 500; color: #989e99;'>"+item.label+"</small>")
	        .appendTo( ul );
	  };

    });
</script>

</body>	

</html>