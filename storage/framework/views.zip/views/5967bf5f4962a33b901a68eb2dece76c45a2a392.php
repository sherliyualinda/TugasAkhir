<!DOCTYPE html>
<html>
<head>
	<title>Latihan Input Data</title>
</head>
<body>

<form action="/formulir/proses_form" method="post">
	<input type="hidden" name="_token" value="<?php echo csrf_token()?>">
	Nama: <input type="text" name="nama"></input><br>
	Alamat: <input type="text" name="alamat"></input><br>
	<input type="submit" value="simpan"></input>
</form>

</body>
</html>