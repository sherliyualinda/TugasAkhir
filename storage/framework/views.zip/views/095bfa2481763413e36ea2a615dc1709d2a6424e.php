<!DOCTYPE html>
<html>
<head>
	<title>Latihan CRUD</title>
</head>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/js/app.js')); ?>">
<style type="text/css">
	/*.pagination li{
		float: left;
		list-style-type: none;
		margin:5px;
	}*/
</style>
<body>
<div class="container">
	<div class="card">
		<div class="card-body"><br>
			<a href="/pegawai/logout_proses" class="btn btn-danger btn-sm">Logout</a> &nbsp <b>Welcome, <?php echo e(Session::get('name')); ?> !</b> 
			<h1 class="text-center"> Data Pegawai </h1>
			<a class="btn btn-warning btn-sm" href="/pegawai/tambah_pegawai"> + Tambah Pegawai </a> &nbsp
			<a class="btn btn-warning btn-sm" href="/upload"> + Upload File </a>

			<div class="form-group"></div>
			<form action="/pegawai/cari_proses" method="get" class="form-inline">
				<input class="form-control" type="text" name="cari" placeholder="Cari Berdasarkan Nama/Umur" size="27"></input> <input class="btn btn-submit" type="submit" value="Cari"></input>
			</form>
			<br>
			<table class="table table-bordered table-striped table-hover" border="1">
				<thead>
					<th><center> Nama </th>
					<th><center> Jabatan </th>
					<th><center> Umur </th>
					<th><center> Alamat </th>
					<th><center> Aksi </th>
				</thead>
				<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tbody>
					<td> <?php echo e($p->pegawai_nama); ?> </td>
					<td> <?php echo e($p->pegawai_jabatan); ?> </td>
					<td><center> <?php echo e($p->pegawai_umur); ?> </td>
					<td> <?php echo e($p->pegawai_alamat); ?> </td>
					<td><center> <a class="btn btn-warning btn-sm" href="/pegawai/edit_pegawai/<?php echo e($p->pegawai_id); ?>"> Edit </a> | <a class="btn btn-danger btn-sm" href="/pegawai/hapus_pegawai/<?php echo e($p->pegawai_id); ?>"> Hapus </a> </td>
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>

			<p>Halaman : <?php echo e($pegawai->currentPage()); ?><br>
			Jumlah Data : <?php echo e($pegawai->total()); ?><br>
			Data Per Halaman : <?php echo e($pegawai->perPage()); ?></p>

			<ul class="pagination"><?php echo e($pegawai->links()); ?></ul>
		</div>
	</div>
</div>
</body>
</html>