<!-- <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light"> -->
	<div class="logo col-lg-4">
		<a title="" href="<?php echo e(asset('/sosial-media/beranda')); ?>"><img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/desaku-logo.png')); ?>" alt="" style="max-height: 50px;"></a>
	</div>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<div class="col-lg-4 d-flex justify-content-center">
			<form class="form-inline my-lg-0">
				<input class="form-control mr-sm-2" type="search" id="search" name="search" placeholder="Search" aria-label="Search">
				<input type="hidden" name="searchUname"></input>
			</form>
		</div>
		<ul class="navbar-nav col-lg-8 d-flex justify-content-end">
			<li class="nav-item active">
				<a class="nav-link" href="<?php echo e(asset('/sosial-media/beranda')); ?>" title="Home" data-ripple=""><i class="ti-home" style="color:black;"></i></a>
				<!-- <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a> -->
			</li>
			<li class="nav-item">
				<a class="nav-link notif" title="Notification" id="notif" data-ripple="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<i class="ti-bell" style="color:black;"></i>
					<?php $jml = 0;
					if($notif && $notif_like && $jml_notif_group && $jml_undangan){
						foreach ($notif as $row){
							foreach ($notif_like as $row_like){
								foreach ($jml_notif_group as $row_gr){
									foreach ($jml_undangan as $row_und){
										if(($row->jml)+($row_like->jml)+($row_gr->jml)+($row_und->jml) != 0){
											$jml = ($row->jml)+($row_like->jml)+($row_gr->jml)+($row_und->jml);
										}
									}
								}
							}
						}
					}else if($notif){
						foreach ($notif as $row){
							if($row->jml != 0){
								$jml = $row->jml;
							}
						}
					}else if($jml_notif_group){
						foreach ($jml_notif_group as $row_gr){
							if($row_gr->jml != 0){
								$jml = $row_gr->jml;
							}
						}
					}else if($notif_like){
						foreach ($notif_like as $row_like){
							if($row_like->jml != 0){
								$jml = $row_like->jml;
							}
						}
					}else if($jml_undangan){
						foreach ($jml_undangan as $row_und){
							$jml = $row_und->jml;
						}
					} ?>
					<?php if($jml != 0): ?>
						<span class="badge" id="jml_notif"><?php echo e($jml); ?></span>
					<?php endif; ?>
				</a>
				<div class="dropdown-menu dropdown-menu-right" style="min-width: 75%">
					<h6 style="text-align: center">Notifikasi</h6>
					<hr style="margin-top: 0.25rem; margin-bottom: 0.25rem;">
					<div class="a" style="overflow-y: auto; max-height: 250px;">
					<?php if($jml != 0): ?>
						<?php if($isi_notif || $isi_notif_like || $isi_notif_group || $undangan): ?>
							<?php $__currentLoopData = $undangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $und): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<button class="dropdown-item" type="button">
									<div class="media">
										<img src="<?php echo e((url('/data_file/foto_profil/'.$und->foto_pengirim))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
									  	<div class="media-body align-self-center" style="white-space: initial; width:200px; height: 90px;">
									    	<small style="color: black"><b><?php echo e($und->username_pengirim); ?></b> 
									    		mengundang anda ke dalam grup <strong><?php echo e($und->nama_group); ?></strong>
									    	</small>
									    	<small style="color: #989e99">-<?php echo e(date_format(date_create($und->tanggal_undangan), "d M Y H:i A")); ?></small>
									    	<br>
									    	<a href="/sosial-media/terima_undangan_grup/<?php echo e($und->id); ?>" class="btn btn-success btn-sm" role="button" style="position: relative; top:10px; border: 1px solid #358f66; background: #358f66;">Terima</a>
									    	<a href="/sosial-media/tolak_undangan_grup/<?php echo e($und->id); ?>" class="btn btn-success btn-sm" role="button" style="position: relative; top:10px; border: 1px solid #358f66; background: #358f66;">Tolak</a>
									  	</div>
									</div>
								</button>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $isi_notif_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_notif_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<button class="dropdown-item" type="button">
									<div class="media">
										<img src="<?php echo e((url('/data_file/foto_profil/'.$data_notif_group->foto_profil_post))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
									  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
									    	<small style="color: black"><b><?php echo e($data_notif_group->username_post); ?></b> 
									    		memposting sesuatu di <strong><?php echo e($data_notif_group->nama_group); ?></strong>
									    	</small>
									    	<small style="color: #989e99">-<?php echo e(date_format(date_create($data_notif_group->created_at), "d M Y H:i A")); ?></small>
									  	</div>
									</div>
								</button>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $isi_notif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<button class="dropdown-item" type="button">
									<div class="media">
										<img src="<?php echo e((url('/data_file/foto_profil/'.$row->foto_profil_commentor))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
									  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
									    	<small style="color: black"><b><?php echo e($row->username_commentor); ?></b> 
									    	<?php if(strpos($row->isi_komentar, Session::get('username')) !== false): ?>
									    		menyebut anda dalam komentar: 
									    	<?php else: ?> 
									    		mengomentari postingan anda:
									    	<?php endif; ?>
									    	<?php echo html_entity_decode($row->isi_komentar); ?> 
									    	</small>
									    	<small style="color: #989e99">-<?php echo e(date_format(date_create($row->tanggal_komen), "d M Y H:i A")); ?></small>
									  	</div>
									  	<?php $media = explode(", ", $row->foto_video_konten); ?>
									  	<?php for($x = 0; $x < 1; $x++): ?>
									  		<?php if(strpos($media[$x], '.mp4')): ?>
												<video width="40" height="40" style="object-fit:none; margin-left: 16px;">
												  	<source src="<?php echo e(url('/data_file/'.$media[$x])); ?>" type="video/mp4">
												  	<source src="<?php echo e(url('/data_file/'.$media[$x])); ?>" type="video/ogg">
												  	Your browser does not support the video tag.
												</video>
											<?php else: ?>
										  		<img src="<?php echo e(url('/data_file/'.$media[$x])); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
										  	<?php endif; ?>
									  	<?php endfor; ?>
									</div>
								</button>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $isi_notif_like; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<button class="dropdown-item" type="button">
									<div class="media">
										<img src="<?php echo e((url('/data_file/foto_profil/'.$row_like->foto_profil))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
									  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
									    	<small style="color: black"><b><?php echo e($row_like->username_likers); ?></b> 
									    	menyukai postingan anda
									    	</small>
									    	<small style="color: #989e99">-<?php echo e(date_format(date_create($row_like->tanggal_like), "d M Y H:i A")); ?></small>
									  	</div>
									  	<?php $media = explode(", ", $row_like->foto_video_konten); ?>
									  	<?php for($x = 0; $x < 1; $x++): ?>
									  		<?php if(strpos($media[$x], '.mp4')): ?>
												<video width="40" height="40" style="object-fit:none; margin-left: 16px;">
												  	<source src="<?php echo e(url('/data_file/'.$media[$x])); ?>" type="video/mp4">
												  	<source src="<?php echo e(url('/data_file/'.$media[$x])); ?>" type="video/ogg">
												  	Your browser does not support the video tag.
												</video>
											<?php else: ?>
										  		<img src="<?php echo e(url('/data_file/'.$media[$x])); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
										  	<?php endif; ?>
									  	<?php endfor; ?>
									</div>
								</button>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php elseif($isi_notif): ?>
							<?php $__currentLoopData = $isi_notif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<button class="dropdown-item" type="button">
									<div class="media">
										<img src="<?php echo e((url('/data_file/foto_profil/'.$row->foto_profil_commentor))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
									  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
									    	<small style="color: black"><b><?php echo e($row->username_commentor); ?></b> 
									    	<?php if(strpos($row->isi_komentar, Session::get('username')) !== false): ?>
									    		menyebut anda dalam komentar: 
									    	<?php else: ?> 
									    		mengomentari postingan anda:
									    	<?php endif; ?>
									    	<?php echo html_entity_decode($row->isi_komentar); ?> 
									    	</small>
									    	<small style="color: #989e99">-<?php echo e(date_format(date_create($row->tanggal_komen), "d M Y H:i A")); ?></small>
									  	</div>
									  	<?php $media = explode(", ", $row->foto_video_konten); ?>
									  	<?php for($x = 0; $x < 1; $x++): ?>
									  		<?php if(strpos($media[$x], '.mp4')): ?>
												<video width="40" height="40" style="object-fit:none; margin-left: 16px;">
												  	<source src="<?php echo e(url('/data_file/'.$media[$x])); ?>" type="video/mp4">
												  	<source src="<?php echo e(url('/data_file/'.$media[$x])); ?>" type="video/ogg">
												  	Your browser does not support the video tag.
												</video>
											<?php else: ?>
										  		<img src="<?php echo e(url('/data_file/'.$media[$x])); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
										  	<?php endif; ?>
									  	<?php endfor; ?>
									</div>
								</button>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php elseif($isi_notif_group): ?>
							<?php $__currentLoopData = $isi_notif_grup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_notif_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<button class="dropdown-item" type="button">
									<div class="media">
										<img src="<?php echo e((url('/data_file/foto_profil/'.$data_notif_group->foto_profil_post))); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
									  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
									    	<small style="color: black"><b><?php echo e($data_notif_group->username_post); ?></b> 
									    		memposting sesuatu di <strong><?php echo e($data_notif_group->nama_group); ?></strong>
									    	</small>
									    	<small style="color: #989e99">-<?php echo e(date_format(date_create($data_notif_group->created_at), "d M Y H:i A")); ?></small>
									  	</div>
									</div>
								</button>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<div align="center"> Tidak Ada Notifikasi </div>
						<?php endif; ?>
					<?php elseif($jml == 0): ?>
						<div align="center"> Tidak Ada Notifikasi </div>
					<?php else: ?>
						<div align="center"> Notifikasi Dinonaktifkan </div>
					<?php endif; ?>
					</div>
				</div>
			</li>
			<li class="nav-item">
				<a class="nav-link notif" href="<?php echo e(asset('/sosial-media/chat')); ?>" title="Message" data-ripple="">
					<i class="fa fa-send-o" style="color:black;"></i> 
					<?php if(isset($notif_pesan)): ?>
						<?php $__currentLoopData = $notif_pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($notif->jml != 0): ?>
								<span class="badge"><?php echo e($notif->jml); ?></span>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link notif" href="<?php echo e(asset('/sosial-media/halaman_group')); ?>" title="Group" title="Group Notification" id="notif_group" data-ripple="">
					<i class="fa fa-group" style="color:black;"></i>
					<?php if(isset($notif_group)): ?>
						<?php $__currentLoopData = $notif_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($row->jml != 0): ?>
								<span class="badge" id="jml_notif_group"><?php echo e($row->jml); ?></span>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</a>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<img src="<?php echo (Session::get('foto_profil') != null) ? (Session::get('foto_profil')) : asset('user.jpg') ;?>" alt="" style="height: 20px;width:20px;border-radius:50%;vertical-align:sub;">
				</a>
				<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
					<a class="dropdown-item" href="#" title=""><?php echo e(Session::get('nama')); ?></a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="/sosial-media/profil/<?php echo e(Session::get('username')); ?>" title=""><i class="ti-user" style="padding-right: 1rem;"></i>Profil</a>
					<a class="dropdown-item" href="" title=""><i class="fa fa-bar-chart-o" style="padding-right: 1rem;"></i>Insight</a>
					<a class="dropdown-item" href="<?php echo e(asset('/sosial-media/pengaturan')); ?>" title=""><i class="ti-settings" style="padding-right: 1rem;"></i>Pengaturan</a>
					<a class="dropdown-item" href="<?php echo e(asset('/sosial-media/logout_proses')); ?>" title=""><i class="ti-power-off" style="padding-right: 1rem;"></i>Logout</a>
				</div>
			</li>
		</ul>
	</div>
<!-- </nav> -->