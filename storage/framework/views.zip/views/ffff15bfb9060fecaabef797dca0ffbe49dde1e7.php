<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Sosial Media Desaku</title>
	<link rel="icon" href="/logo-home.png" type="image/png" sizes="16x16"> 
    
    
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('jquery-ui-1.12.1.custom/jquery-ui.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/chat-detail.css')); ?>">

</head>
<body>
<!--<div class="se-pre-con"></div>-->
<div class="theme-layout">
	
	<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
		<?php echo $__env->make('theme.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</nav>
		
	<section>
		<div class="gap gray-bg">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="row justify-content-center" id="page-contents" style="padding-left: 0;">
							<div class="central-meta col-lg-3" style="padding: 15px;">
								<div class="modal-header d-flex justify-content-left" style="padding: 0.75rem 0rem;">
						          <h6 class="modal-title"><a href="<?php echo e(asset('/sosial-media/chat')); ?>">Pesan</a></h6>
						          <a href="#" data-toggle="modal" data-target="#myModal" style="height: 24px;"><i class="fa fa-pencil-square-o" style="font-size:24px"></i></a>
						        </div>
				        		<div class="input-group flex-nowrap" style="margin-top: 10px; margin-bottom: 10px;" id="cari">
									<!-- <input type="text" class="form-control" placeholder="cari pesan"> -->
									<div id="kolom_input" style="width: 100%;"></div>
									<div class="input-group-append">
								    	<span class="input-group-text" id="addon-wrapping">
								    		<i class="fa fa-search"></i>
								    	</span>
									</div>
								</div>
						        <div class="list-group list-group-flush" style="height: 339px; overflow-y: auto; max-height: 339px;" id="list_yang_dicari">
						        	<?php $__currentLoopData = $list_chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(auth()->user()->pengguna->username == $list->username_pengirim) {
											$username_yang_tampil = $list->username_penerima;
										}else{
											$username_yang_tampil = $list->username_pengirim;
										} ?>
										<div class="list-hover" id="room_<?php echo e($list->id_room_chat); ?>">
											<a href="/sosial-media/chat/<?php echo e($list->id_room_chat); ?>" class="list-group-item list-group-item-action">
												<div class="media">
													<?php if(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil) == url('/data_file/'.$list->username_pengirim.'/foto_profil/'.$list->foto_pengirim)): ?>
														<img src="<?php echo e(url('/data_file/'.$list->username_penerima.'/foto_profil/'.$list->foto_penerima)); ?>" class="align-self-center mr-3" alt="..." style="width: 50px; height: 50px; border-radius: 50%;">
													<?php else: ?>
														<img src="<?php echo e(url('/data_file/'.$list->username_pengirim.'/foto_profil/'.$list->foto_pengirim)); ?>" class="align-self-center mr-3" alt="..." style="width: 50px; height: 50px; border-radius: 50%;">
													<?php endif; ?>
													<div class="media-body align-self-center">
														<h6 class="mt-0" style="margin-bottom: 0rem; font-weight: 100; color: black;"><?php echo e($username_yang_tampil); ?></h6>
														<?php if($list->isi_chat != null): ?>
															<small style="color: #989e99" class="isi_chat<?php echo e($list->id_room_chat); ?>"><?php echo e(strip_tags($list->isi_chat)); ?></small>
														<?php else: ?>
															<small style="color: #989e99" class="isi_chat<?php echo e($list->id_room_chat); ?>">
																<?php if(auth()->user()->pengguna->username == $list->username_pengirim): ?>
																	Anda mengirim media
																<?php else: ?>
																	<?php echo e($list->username_pengirim); ?> mengirim media
																<?php endif; ?>
															</small>
														<?php endif; ?>
														<small class="tgl_chat<?php echo e($list->id_room_chat); ?>" style="color: #989e99">-<?php echo e(date_format(date_create($list->tanggal_chat), "d M Y H:i")); ?></small>
													</div>
													<?php $__currentLoopData = $jumlah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php if($list->id_room_chat == $j->id_room_chat): ?>
															<span class="badge pull-right align-self-center" style="margin-right: 5px;"><?php echo e($j->jml); ?></span>
														<?php endif; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>
											</a>
											<i class="ti-trash align-self-center" onclick="modalHapusRoomChat('<?php echo e($list->id_room_chat); ?>', '<?php echo e($username_yang_tampil); ?>')" style="cursor: pointer; color: red;" title="Hapus"></i>
										</div>
						        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						        </div>
							</div>
							<div class="central-meta item col-lg-7" style="padding: 15px;">
								<div class="modal-header d-flex justify-content-left" style="padding: 0.75rem 0rem;">
									<div class="media">
									<?php $__currentLoopData = $data_chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(url('/data_file/'.auth()->user()->pengguna->username.'/foto_profil/'.auth()->user()->pengguna->foto_profil) == url('/data_file/'.$list->username_pengirim.'/foto_profil/'.$list->foto_pengirim)): ?>
						          			<img src="<?php echo e(url('/data_file/'.$list->username_penerima.'/foto_profil/'.$list->foto_penerima)); ?>" class="align-self-center mr-3" alt="..." style="width: 20px; height: 20px; border-radius: 50%;">
						          		<?php else: ?>
						          			<img src="<?php echo e(url('/data_file/'.$list->username_pengirim.'/foto_profil/'.$list->foto_pengirim)); ?>" class="align-self-center mr-3" alt="..." style="width: 20px; height: 20px; border-radius: 50%;">
						          		<?php endif; ?>
						          		<div class="media-body align-self-center">
							          		<?php if(auth()->user()->pengguna->username == $chat->username_pengirim) {
													$username_yang_tampil = $chat->username_penerima;
											}else{
													$username_yang_tampil = $chat->username_pengirim;
											} ?>
						          			<a href="/sosial-media/profil/<?php echo e($username_yang_tampil); ?>" style="font-weight: 600">
						          				<?php echo e($username_yang_tampil); ?>

						          			</a>
						          		</div>
						          		<?php break; ?>
						          	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						          	</div>
						          	
						        </div>
						        <div class="modal-body" style="height: 80%; overflow-y: auto; max-height: 347px;" id="isi">
						        <?php $__currentLoopData = $data_chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						        	<?php if($chat->username_pengirim != auth()->user()->pengguna->username): ?>
						        		<div class="container">
											<?php if($chat->isi_chat != null): ?>
												<p style="text-align:left;"><?php echo html_entity_decode($chat->isi_chat); ?></p>
											<?php else: ?>
												<?php if(strpos($chat->media, '.mp4')): ?>
													<video width="100%" height="100%" controls>
														<source src="<?php echo e(url('/data_file/chat/'.$chat->id_room_chat.'/'.$chat->media)); ?>" type="video/mp4">
														<source src="<?php echo e(url('/data_file/chat/'.$chat->id_room_chat.'/'.$chat->media)); ?>" type="video/ogg">
														Your browser does not support the video tag.
													</video>
												<?php else: ?>
													<img id="myImg-<?php echo e($chat->id_chat); ?>" class="modal_img" data-id="<?php echo e($chat->id_chat); ?>" src="<?php echo e(url('/data_file/chat/'.$chat->id_room_chat.'/'.$chat->media)); ?>" style="cursor: pointer;">
												<?php endif; ?>
											<?php endif; ?>
											<span class="time-right"><?php echo e(date_format(date_create($chat->tanggal_chat), "d M Y H:i")); ?></span>
										</div>
									<?php else: ?>
										<div class="hover-chat" id="container_<?php echo e($chat->id_chat); ?>">
											<div class="container darker">
												<?php if($chat->isi_chat != null): ?>
													<p style="text-align: left;"><?php echo html_entity_decode($chat->isi_chat); ?></p>
												<?php else: ?>
													<?php if(strpos($chat->media, '.mp4')): ?>
														<video width="100%" height="100%" controls>
															<source src="<?php echo e(url('/data_file/chat/'.$chat->id_room_chat.'/'.$chat->media)); ?>" type="video/mp4">
															<source src="<?php echo e(url('/data_file/chat/'.$chat->id_room_chat.'/'.$chat->media)); ?>" type="video/ogg">
															Your browser does not support the video tag.
														</video>
													<?php else: ?>
														<img id="myImg-<?php echo e($chat->id_chat); ?>" class="modal_img" data-id="<?php echo e($chat->id_chat); ?>" src="<?php echo e(url('/data_file/chat/'.$chat->id_room_chat.'/'.date_format(date_create($chat->tanggal_chat), "d-m-Y").'/'.$chat->media)); ?>" style="cursor: pointer;">
													<?php endif; ?>
												<?php endif; ?>
												<span class="time-left">
													<?php echo e(date_format(date_create($chat->tanggal_chat), "d M Y H:i")); ?>

													<a title="Hapus" onclick="modalHapusChat('<?php echo e($chat->id_chat); ?>', '<?php echo e($list->id_room_chat); ?>', '<?php echo e(Auth::user()->pengguna->id_pengguna); ?>', '<?php echo e($username_yang_tampil); ?>')" style="cursor: pointer; color: red; font-size: 16px;"><i class="ti-trash hide"></i></a> 
												</span>
											</div>
										</div>
									<?php endif; ?>
									<div id="myModalImg/<?php echo e($chat->id_chat); ?>" class="modal" style="display: none; position: fixed; padding-top: 50px; background-color: rgb(0,0,0); background-color: rgba(0,0,0,0.9); overflow-y: auto;">
									  	<span class="close" id="close/<?php echo e($chat->id_chat); ?>" style="position: fixed; top: 15px; right: 35px; color: #f1f1f1; font-size: 40px; font-weight: bold; transition: 0.3s;">&times;</span>
								  		<img class="modal-content" id="img/<?php echo e($chat->id_chat); ?>" style="margin: auto; display: block; width: 50%; max-width: 50%; object-fit: cover;">
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    </div>
						        <div class="modal-footer align-items-end" style="padding: 0.5rem 0rem;">
						        	<div class="post-comt-box2" style="width:100%; padding-left:0;">
						        		<form method="post" action="/sosial-media/chat_proses" enctype="multipart/form-data">
						        		<?php echo e(csrf_field()); ?>

						        			<input type="hidden" name="id_room_chat" value="<?php echo e($chat->id_room_chat); ?>" class="room"></input>
						        			<?php if($chat->username_penerima == auth()->user()->pengguna->username): ?>
						        				<input type="hidden" name="username_penerima" value="<?php echo e($chat->username_pengirim); ?>" class="penerima"></input>
						        			<?php else: ?>
						        				<input type="hidden" name="username_penerima" value="<?php echo e($chat->username_penerima); ?>" class="penerima"></input>
						        			<?php endif; ?>
						        			<div class="input-group mb-3">
  												<div class="input-group-prepend">
								        			<div class="attachments">
														<ul>
															<li>
															  	<i class="fa fa-image"></i>
															  	<label class="fileContainer">
																	<input type="file" name="file_foto" id="pro-image">
																</label>
															</li>
														</ul>
													</div>
												</div>
							        			<textarea  name="isi_chat" style="width: 93%; overflow-y: auto;"></textarea>
							        			<button type="submit" class="btn btn-submit" style="border-radius: 3px;">Post</button>
							        		</div>
						        		</form>
						        	</div>
						        </div>
							</div>
						</div>	
					</div>
				</div>
			</div>
		</div>	
	</section>
	<div class="modal fade" id="myModal" role="dialog">
	    <div class="modal-dialog modal-sm modal-dialog-centered" style="max-width: 400px;">
	      	<div class="modal-content">
		        <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
		          	<h6 class="modal-title">Buat Pesan Baru</h6>
		        </div>
        		<div class="input-group flex-nowrap" id="cari_teman">
        			<div class="input-group-prepend">
				    	<span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
				    		Ke: 
				    	</span>
					</div>
					<!-- <input type="text" class="form-control form-control-sm" placeholder="cari.." style="border-radius: 0rem;"> -->
					<div id="kolom_input_cari" style="width: 100%;"></div>
				</div>
	        	<ul class="list-group list-group-flush" style="overflow-y: scroll;" id="teman_yang_dicari">
		        	<?php if($teman != NULL): ?>
						<?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="list-group list-group-flush" style="max-height: 315px;">
				        	<!-- <a href="#" onclick="isiChatKosong('<?php echo e(url('/data_file/foto_profil/'.$data->foto_profil)); ?>', '<?php echo e($data->username); ?>', '<?php echo e(Session::get('id_pengguna')); ?>', '<?php echo e(Session::get('username')); ?>')" class="list-group-item list-group-item-action" data-dismiss="modal"> -->
				        	<a href="#" onclick="cek_chat('<?php echo e(url('/data_file/'.$data->username.'/foto_profil/'.$data->foto_profil)); ?>', '<?php echo e($data->username); ?>', '<?php echo e(auth()->user()->pengguna->id_pengguna); ?>', '<?php echo e(auth()->user()->pengguna->username); ?>')" class="list-group-item list-group-item-action" data-dismiss="modal" style="padding-left: 10px; padding-right: 10px;">
				        		<div class="media">
									<img src="<?php echo e(url('/data_file/'.$data->username.'/foto_profil/'.$data->foto_profil)); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
								  	<div class="media-body align-self-center">
								  		<small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data->username); ?></small><br>
								    	<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data->nama); ?></small>
								  	</div>
								</div>
				        	</a>
				        </div>
		        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
					<?php else: ?>
						<li>
							<div align="center">Tidak ada teman</div>
						</li>
					<?php endif; ?>
	        	</ul>
	      	</div>
	    </div>
	</div>

</div>		
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/script.js')); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('js/chat-detail.js')); ?>"></script>
<script type="text/javascript">
    // CSRF Token
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function(){

      $( "#search" ).autocomplete({
      	appendTo: "#container_search",
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url:"<?php echo e(route('sosial-media.cari_pengguna')); ?>",
            type: 'post',
            dataType: "json",
            data: {
               _token: CSRF_TOKEN,
               search: request.term
            },
            success: function( data ) {
               response( data );
            }
          });
        },
        select: function (event, ui) {
           let username = ui.item.value;
           window.location.href = window.location.origin+"/sosial-media/profil/"+username;
           return false;
        }
      })
      .data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	      return $( "<li>" )
	        .append( "<div class='media'><img src='"+item.icon+"' class='align-self-center mr-3' alt='...' style='width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;'> <div class='media-body align-self-center'> <small style='font-weight: 700; color: black; margin-bottom: 0rem;'>"+item.value+"</small><br><small class='mt-0' style='margin-bottom: 0rem; font-weight: 500; color: #989e99;'>"+item.label+"</small>")
	        .appendTo( ul );
	  };

    });

	// var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
	// $('#notif').click(function () {
	// 	$.ajax({
	// 		url: "<?php echo e(route('sosial-media.update_notif')); ?>",
	// 		type: 'post',
	// 		// dataType: "json",
	// 		data: {
	// 			_token: CSRF_TOKEN
	// 		},
	// 		success: function (data) {
	// 			if (document.getElementById("jml_notif")) {
	// 				document.getElementById("jml_notif").style.visibility = "hidden";
	// 			}
	// 		}
	// 	});
	// });

	function isiChatKosong(foto_profil, username_penerima, id_pengguna_pengirim, username_pengirim) {
		let html = '';
		html += '<div class="modal-header d-flex justify-content-left" style="padding: 0.75rem 0rem;"> <div class="media"> <img src="' + foto_profil + '" class="align-self-center mr-3" style="width: 20px; height: 20px; border-radius: 50%;"><div class="media-body align-self-center"><a href="/sosial-media/profil/' + username_penerima + '" style="font-weight: 600">' + username_penerima + '</a></div></div></div><div class="modal-body" style="height: 80%; overflow-y: auto; max-height: 347px;"></div><div class="modal-footer align-items-end" style="padding: 0.5rem 0rem;"><div class="post-comt-box2" style="width:100%; padding-left:0;"><form method="post" action="/sosial-media/chat_proses" enctype="multipart/form-data"><?php echo e(csrf_field()); ?><input type="hidden" name="username_penerima" value="' + username_penerima + '" class="penerima"></input><input type="hidden" name="username_pengirim" value="' + username_pengirim + '"></input><input type="hidden" name="id_pengguna" value="' + id_pengguna_pengirim + '"></input><div class="input-group mb-3"><div class="input-group-prepend"><div class="attachments"><ul><li><i class="fa fa-image"></i><label class="fileContainer"><input type="file" name="file_foto[]" id="pro-image"></label></li></ul></div></div><textarea  name="isi_chat" style="width: 93%;"></textarea><button type="submit" class="btn btn-submit" style="border-radius: 3px;">Post</button></div></form></div></div>';
		$('.col-lg-7').html(html);

		$('#pro-image').on('change', function () {
			var formData = new FormData();
			var files = $('#pro-image')[0].files[0];
			formData.append('gambar', files);
			var username_penerima = $('.penerima').val();
			formData.append('username_penerima', username_penerima);
			var url = window.location.origin+"/sosial-media/chat_proses";
			$.ajax({
				url: url,
				type: "post",
				headers: {
					'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
				},
				contentType: false,
				processData: false,
				data: formData,
				success: function (response) {
					if (response.length !== 0) {
						for (var i = 0; i < response.length; i++) {
							window.location.href = window.location.origin+"/sosial-media/chat/" + response[i].id_room_chat;
						}
					}
				}
			});
		});
	}

</script>
</body>	

</html>