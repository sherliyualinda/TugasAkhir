<!DOCTYPE html>
<html>
<head>
	<title>Edit Data Pegawai</title>
</head>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/js/app.js')); ?>">
<body>
	<div class="container">
		<div class="card">
			<div class="card-body">
				<h1 class="text-center"> Edit Data Pegawai </h1>
					<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<form action="/pegawai/edit_proses" method="post" class="form-horizontal">
						<?php echo e(csrf_field()); ?>

						<div class="form-group"></div>
						<div class="form-group">
							<input type="hidden" name="pegawai_id" value="<?php echo e($p->pegawai_id); ?>"></input>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Nama : </label>
							<div class="col-sm-9">
								<input class="form-control" type="text" name="pegawai_nama" value="<?php echo e($p->pegawai_nama); ?>" required="required"></input>
							</div>
						</div> 
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Jabatan : </label>
							<div class="col-sm-9">
								<input class="form-control" type="text" name="pegawai_jabatan" value="<?php echo e($p->pegawai_jabatan); ?>" required="required"></input>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Umur : </label>
							<div class="col-sm-9">
								<input class="form-control" type="number" name="pegawai_umur" value="<?php echo e($p->pegawai_umur); ?>" required="required"></input> 
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama"> Alamat : </label>
							<div class="col-sm-9">
								<textarea class="form-control" name="pegawai_alamat" required="required"><?php echo e($p->pegawai_alamat); ?></textarea>
							</div>
						</div>
						<div class="form-group" align="center">
								<a href="/pegawai">Kembali</a> &nbsp <input class="btn btn-submit" type="submit" value="Simpan Data"></input>
						</div>
					</form>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
</body>
</html>