<!DOCTYPE html>
<html>
<head>
	<title>Passing Data Controller Ke View</title>
</head>
<body>

<p> Latihan Passing Data</p>
<br>
<p> Nama: <?php echo e($nama); ?> </p>
<p> Hari Kerja: </p>
<ul>
	<?php $__currentLoopData = $hari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li> <?php echo e($h); ?> </li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</body>
</html>