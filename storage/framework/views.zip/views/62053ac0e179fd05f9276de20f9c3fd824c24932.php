<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="padding-left: 32px; padding-bottom: 10px; height: 250px; padding-left: 0; padding-right: 32px;">
    
    <div class="carousel-inner">
        <?php $__currentLoopData = $api_wisata['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($loop->iteration == 1 ? 'active' : ''); ?>" data-item="<?php echo e($loop->iteration); ?>">
                <img src="<?php echo e($api['foto']); ?>" class="d-block w-100" style="height: 250px; padding-bottom: 10px; object-fit: cover;">
                <div class="carousel-caption d-none d-md-block">
                    <div style="margin-bottom: 10px;">
                        <h5><a href="<?php echo e($api['url']); ?>" target="_blank"><?php echo e($api['nama']); ?></a></h5>
                        <small class="badge badge-success" style="display: inline"><?php echo e($api['jam']); ?></small>
                        <small class="badge badge-warning" style="display: inline"><?php echo e($api['biaya']); ?></small>
                    </div>
                </div>
            </div>
            <?php if($loop->iteration == 3): ?>
            <?php break; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
</div>