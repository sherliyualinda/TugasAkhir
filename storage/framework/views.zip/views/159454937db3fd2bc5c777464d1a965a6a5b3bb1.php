<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
	<title>Sosial Media Desaku</title>
	<link rel="icon" href="images/fav.png" type="image/png" sizes="16x16"> 
	<!-- <script src='https://kit.fontawesome.com/a076d05399.js'></script> -->
	<!-- <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> -->
    
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/css/responsive.css')); ?>">

</head>
<style type="text/css">
.feature-photo{
	padding-top: 65px;
}

.feature-photo .container-fluid {
	height: auto;
}

.edit-phto:hover {
    background: gray none repeat scroll 0 0;
    border: 1px solid gray;
    color: #fff;
}

.modal-open .modal {
	background-color: #00000094;
}
</style>
<body>
<!--<div class="se-pre-con"></div>-->
<div class="theme-layout">
	
	<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
		<div class="logo col-lg-4">
			<a title="" href="newsfeed.html"><img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/Desaku4.png')); ?>" alt=""></a>
		</div>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<!-- <div class="collapse navbar-collapse" id="navbarSupportedContent"> -->
			<div class="col-lg-4 d-flex justify-content-center">
				<form class="form-inline my-lg-0">
					<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
				</form>
			</div>
			<ul class="navbar-nav col-lg-4 d-flex justify-content-end">
				<li class="nav-item active">
					<a class="nav-link" href="<?php echo e(asset('/sosial-media/beranda')); ?>" title="Home" data-ripple=""><i class="ti-home"></i></a>
					<!-- <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a> -->
				</li>
				<li class="nav-item">
					<a href="#" class="nav-link notif" title="Notification" data-ripple="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<i class="ti-bell" style="color:black;"></i><span class="badge">4</span>
					</a>
					<div class="dropdown-menu dropdown-menu-left" style="min-width: 75%">
						<h6 style="text-align: center">Notifikasi</h6>
						<hr style="margin-top: 0.25rem; margin-bottom: 0.25rem;">
						<div class="a" style="overflow-y: scroll; max-height: 250px;">
							<button class="dropdown-item" type="button">
								<div class="media">
									<img src="<?php echo e(asset('user.jpg')); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
								  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
								    	<small style="color: black"><b>afraaknim</b> menyebut anda dalam komentar: @desa_sukajati  hehehe iya </small>
								    	<small style="color: #989e99">-12:23 PM</small>
								  	</div>
								  	<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
								</div>
							</button>
						    <button class="dropdown-item" type="button">
								<div class="media">
									<img src="<?php echo e(asset('user.jpg')); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
								  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
								    	<small style="color: black"><b>afraaknim</b> menyukai postingan anda</small>
								    	<small style="color: #989e99">-12:23 PM</small>
								  	</div>
								  	<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
								</div>
							</button>
							<button class="dropdown-item" type="button">
								<div class="media">
									<img src="<?php echo e(asset('user.jpg')); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
								  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
								    	<small style="color: black"><b>afraaknim</b> menandai anda pada postingannya</small>
								    	<small style="color: #989e99">-12:23 PM</small>
								  	</div>
								  	<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
								</div>
							</button>
							<button class="dropdown-item" type="button">
								<div class="media">
									<img src="<?php echo e(asset('user.jpg')); ?>" class="align-self-center mr-3" alt="..." style="width: 30px; height: 30px; border-radius: 50%;">
								  	<div class="media-body align-self-center" style="white-space: initial; width:200px;">
								    	<small style="color: black"><b>erinfdl</b> menyebut anda dalam komentar: @desa_sukajati  hehehe iya </small>
								    	<small style="color: #989e99">-12:23 PM</small>
								  	</div>
								  	<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" class="align-self-center ml-3" alt="..." style="width: 40px; height: 40px; border-radius: 0%;">
								</div>
							</button>
						</div>
					</div>
				</li>
				<li class="nav-item">
					<a href="<?php echo e(asset('/sosial-media/chat')); ?>" class="nav-link notif" title="Messages" data-ripple=""><i class="fa fa-send-o" style="color:black;"></i> <span class="badge">4</span> </a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<img src="<?php echo (Session::get('foto') == null) ? (Session::get('foto')) : asset('user.jpg') ;?>" alt="" style="height: 20px;width:20px;border-radius:50%;vertical-align:sub;">
					</a>
					<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="#" title=""><?php echo e(Session::get('nama')); ?></a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="<?php echo e(asset('/sosial-media/profil')); ?>" title=""><i class="ti-user" style="padding-right: 1rem;"></i>Profil</a>
						<a class="dropdown-item" href="" title=""><i class="fa fa-bar-chart-o" style="padding-right: 1rem;"></i>Insight</a>
						<a class="dropdown-item" href="<?php echo e(asset('/sosial-media/pengaturan')); ?>" title=""><i class="ti-settings" style="padding-right: 1rem;"></i>Pengaturan Akun</a>
						<a class="dropdown-item" onclick="if(!confirm('Anda yakin ingin logout?')) return false;" href="<?php echo e(asset('/sosial-media/logout_proses')); ?>" title=""><i class="ti-power-off" style="padding-right: 1rem;"></i>Logout</a>
					</div>
				</li>
			</ul>
		<!-- </div> -->
	</nav>
    
    <section>
		<div class="feature-photo">
			<figure>
				<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/timeline-4.jpg')); ?>" alt="">
			</figure>
			<form class="edit-phto" style="bottom: 120px;">
				<i class="fa fa-camera-retro"></i>
				<label class="fileContainer">
					Edit Cover Photo
					<input type="file"/>
				</label>
			</form>
			<div class="container-fluid">
				<div class="row merged">
					<div class="col-lg-5 col-sm-4"></div>
					<div class="col-lg-2 col-sm-3">
						<div class="user-avatar">
							<figure>
								<img src="<?php echo e(Session::get('foto')); ?>" alt="">
								<form class="edit-phto">
									<i class="fa fa-camera-retro"></i>
									<label class="fileContainer">
										Edit Display Photo
										<input type="file"/>
									</label>
								</form>
							</figure>
						</div>
					</div>
<!-- 					<div class="col-lg-5 col-sm-4"></div>
					<div class="col-lg-4 col-sm-4"></div> -->
					<!-- <div class="col-lg-4 col-sm-4" style="padding-top:40px; text-align:center; color: #000;">
						<h3>Erin Karina</h3>
						<span style="font-size: 16px">@erinfdl</span>
						<br>
						<a href="<?php echo e(asset('/sosial-media/chat')); ?>" class="btn btn-outline-secondary btn-sm" role="button" style="position: relative; top:10px; border: 1px solid;">Pesan</a>
						<button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#myModalUnfollow" style="position: relative; top:10px;">Following</button>
						<button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#myModalMore" style="position: relative; top:10px;"><i class="fa fa-ellipsis-h"></i></button>
						<div style="padding-top:15px">
							<a data-ripple="" style="padding:15px"><b>1</b> Post</a>
							<a href="#" data-toggle="modal" data-target="#myModalFollowers" data-ripple="" style="padding:15px"><b>200k</b> Followers</a>
							<a href="#" data-toggle="modal" data-target="#myModalFollowing" data-ripple="" style="padding:15px"><b>1k</b> Following</a>
						</div>
						<span style="font-size: 12px; color:gray"> Followed by afraaknim, megacandra, and 2 more </span>
					</div>
					<div class="col-lg-4 col-sm-4"></div>
					<div class="col-lg-12 col-sm-5" style="padding-top:15px;"> <hr style="width:95%"> </div> -->
				</div>
			</div>
		</div>
	</section>

	<section style="background-color: #f4f2f2;">
		<div style="padding-top:15px; text-align:center; color: #000;">
			<h3>Erin Karina</h3>
			<span style="font-size: 16px">@erinfdl</span>
			<br>
			<a href="<?php echo e(asset('/sosial-media/chat')); ?>" class="btn btn-outline-secondary btn-sm" role="button" style="position: relative; top:10px; border: 1px solid;">Pesan</a>
			<button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#myModalUnfollow" style="position: relative; top:10px;">Following</button>
			<button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#myModalMore" style="position: relative; top:10px;"><i class="fa fa-ellipsis-h"></i></button>
			<div style="padding-top:15px">
				<a data-ripple="" style="padding:15px"><b>1</b> Post</a>
				<a href="#" data-toggle="modal" data-target="#myModalFollowers" data-ripple="" style="padding:15px"><b>200k</b> Followers</a>
				<a href="#" data-toggle="modal" data-target="#myModalFollowing" data-ripple="" style="padding:15px"><b>1k</b> Following</a>
			</div>
			<span style="font-size: 12px; color:gray"> Followed by afraaknim, megacandra, and 2 more </span>
		</div>
		<div class="col-lg-4 col-sm-4"></div>
		<div class="col-lg-12 col-sm-5" style="padding-top:15px;"> <hr style="width:95%"> </div>
	</section>
	<div class="modal fade" id="myModalFollowers" role="dialog">
	    <div class="modal-dialog modal-sm" style="max-width: 400px;">
	      	<div class="modal-content">
		        <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
		          	<h6 class="modal-title">Followers</h6>
		        </div>
		        <ul class="list-group list-group-flush">
		        	<!-- <li class="list-group-item"> -->
		        		<div class="input-group flex-nowrap">
		        			<div class="input-group-prepend">
						    	<span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
						    		Ke: 
						    	</span>
							</div>
							<input type="text" class="form-control form-control-sm" placeholder="cari.." style="border-radius: 0rem;">
						</div>
		        	<!-- </li> -->
		        	<!-- <li class="list-group-item"> -->
			        	<?php if($teman != NULL): ?>
							<?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="list-group list-group-flush" style="overflow-y: scroll; max-height: 315px;">
						        	<a href="#" class="list-group-item list-group-item-action">
						        		<div class="media">
											<img src="<?php echo e($data->foto); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
										  	<div class="media-body align-self-center">
										  		<small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data->username); ?></small><br>
										    	<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data->nama); ?></small>
										  	</div>
										  	<button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#myModalRemove" style="position: relative; top:10px;">Remove</button>
										</div>
						        	</a>
						        </div>
			        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						<?php else: ?>
							<li>
								<div align="center">Tidak ada teman</div>
							</li>
						<?php endif; ?>
		        	<!-- </li> -->
		        </ul>
	      	</div>
	    </div>
	</div>
	<div class="modal fade" id="myModalFollowing" role="dialog">
	    <div class="modal-dialog modal-sm" style="max-width: 400px;">
	      	<div class="modal-content">
		        <div class="modal-header d-flex justify-content-center" style="padding: 0.5rem;">
		          	<h6 class="modal-title">Following</h6>
		        </div>
		        <ul class="list-group list-group-flush">
		        	<!-- <li class="list-group-item"> -->
		        		<div class="input-group flex-nowrap">
		        			<div class="input-group-prepend">
						    	<span class="input-group-text" id="addon-wrapping" style="border-radius: 0rem;">
						    		Ke: 
						    	</span>
							</div>
							<input type="text" class="form-control form-control-sm" placeholder="cari.." style="border-radius: 0rem;">
						</div>
		        	<!-- </li> -->
		        	<!-- <li class="list-group-item"> -->
			        	<?php if($teman != NULL): ?>
							<?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="list-group list-group-flush" style="overflow-y: scroll; max-height: 315px;">
						        	<a href="#" class="list-group-item list-group-item-action">
						        		<div class="media">
											<img src="<?php echo e($data->foto); ?>" class="align-self-center mr-3" alt="..." style="width: 40px; height: 40px; border-radius: 50%; margin-left: 5px;">
										  	<div class="media-body align-self-center">
										  		<small style="font-weight: 700; color: black; margin-bottom: 0rem;"><?php echo e($data->username); ?></small><br>
										    	<small class="mt-0" style="margin-bottom: 0rem; font-weight: 500; color: #989e99;"><?php echo e($data->nama); ?></small>
										  	</div>
										  	<button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#myModalUnfollow" style="position: relative; top:10px;">Following</button>
										</div>
						        	</a>
						        </div>
			        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						<?php else: ?>
							<li>
								<div align="center">Tidak ada teman</div>
							</li>
						<?php endif; ?>
		        	<!-- </li> -->
		        </ul>
	      	</div>
	    </div>
	</div>

	<section>
		<div class="gap gray-bg">
			<div class="container-fluid" style="width:90%">
				<div class="row">
					<div class="col-lg-12">
						<div class="row" id="page-contents" align="center">
							<div class="col-lg-4" style="padding-bottom:15px;">
								<?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="central-meta item" style="padding:0px; width:360px; height:400px">
									<button class="portfolio-link btn btn-light" 
										onclick="tampilkanDetilPost('<?php echo e($data->id_konten); ?>')" style="border-radius:0; padding:0rem;">  
										<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" 
											style="width:360px; height:400px">
									</button>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div><!-- centerl meta -->
							<div class="col-lg-4">
								<div class="central-meta item" style="padding:0px; width:360px; height:400px">
									<button class="portfolio-link btn btn-light" style="border-radius:0; padding:0rem;">  
										<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" 
											style="width:360px; height:400px">
									</button>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="central-meta item" style="padding:0px; width:360px; height:400px">
									<button class="portfolio-link btn btn-light" style="border-radius:0; padding:0rem;">  
										<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" 
											style="width:360px; height:400px">
									</button>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="central-meta item" style="padding:0px; width:360px; height:400px">
									<button class="portfolio-link btn btn-light" style="border-radius:0; padding:0rem;">  
										<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" 
											style="width:360px; height:400px">
									</button>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="central-meta item" style="padding:0px; width:360px; height:400px">
									<button class="portfolio-link btn btn-light" style="border-radius:0; padding:0rem;">  
										<img src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" 
											style="width:360px; height:400px">
									</button>
								</div>
							</div>
						</div>	
					</div>
				</div>
			</div>
		</div>	
    </section>	

</div>
<div class="side-panel">
	<h4 class="panel-title">General Setting</h4>
	<form method="post">
		<div class="setting-row">
			<span>use night mode</span>
			<input type="checkbox" id="nightmode1"/> 
			<label for="nightmode1" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>Notifications</span>
			<input type="checkbox" id="switch22" /> 
			<label for="switch22" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>Notification sound</span>
			<input type="checkbox" id="switch33" /> 
			<label for="switch33" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>My profile</span>
			<input type="checkbox" id="switch44" /> 
			<label for="switch44" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>Show profile</span>
			<input type="checkbox" id="switch55" /> 
			<label for="switch55" data-on-label="ON" data-off-label="OFF"></label>
		</div>
	</form>
	<h4 class="panel-title">Account Setting</h4>
	<form method="post">
		<div class="setting-row">
			<span>Sub users</span>
			<input type="checkbox" id="switch66" /> 
			<label for="switch66" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>personal account</span>
			<input type="checkbox" id="switch77" /> 
			<label for="switch77" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>Business account</span>
			<input type="checkbox" id="switch88" /> 
			<label for="switch88" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>Show me online</span>
			<input type="checkbox" id="switch99" /> 
			<label for="switch99" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>Delete history</span>
			<input type="checkbox" id="switch101" /> 
			<label for="switch101" data-on-label="ON" data-off-label="OFF"></label>
		</div>
		<div class="setting-row">
			<span>Expose author name</span>
			<input type="checkbox" id="switch111" /> 
			<label for="switch111" data-on-label="ON" data-off-label="OFF"></label>
		</div>
	</form>
</div><!-- side panel -->	

<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<div class="row">
					<div class="col-md-8 modal-image">
						<img class="img-responsive" 
						src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/images/resources/user-post.jpg')); ?>" 
						alt="Image" style="height:491px">
					</div><!--/ col-md-8 -->
					<div class="col-md-4 modal-meta" style="padding-left: 0px;">
						<div class="modal-meta-top">
							<!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
								<span aria-hidden="true">×</span><span class="sr-only">Close</span>
							</button> -->
							<div class="img-poster clearfix">
								<a href="#"><img src="<?php echo e(Session::get('foto')); ?>" alt="" style="width:32px; height:32px; border-radius: 50%;"></a>
								<strong><a href="#" style="padding-left: 10px;">erinfdl</a></strong><small> - Following</small>
								<!-- <div class="d-flex justify-content-end"> -->
									<a href="#" data-toggle="modal" data-target="#myModalMorePost"><i class="fa fa-ellipsis-h"></i></a>
								<!-- </div> -->
							</div><!--/ img-poster -->
							<hr style="margin-top: 0.5rem;margin-bottom: 0.5rem;">
							<ul class="img-comment-list" style="padding:0px;overflow-y: scroll;overflow-x: hidden;max-height: 274px;margin-bottom: 0rem;">
								<div class="row">
									<div class="comment-img col-sm-2" style="padding-right:0">
										<img src="<?php echo e(Session::get('foto')); ?>" class="img-responsive img-circle" style="width:32px;height:32px;border-radius: 50%;">
									</div>
									<div class="comment-text col-sm-10" style="padding-left:10px;">
										<strong style="font-size:16px;"><a href="">erinfdl</a></strong>
										<p style="margin-bottom:0;font-size:14px;color:#000;">Hello this is a test comment.</p> 
										<span style="font-size:11px;color:gray;">on December 5th, 2016</span><button class="btn btn-link" style="font-size: 12px; font-weight: 500;" id="balas" onclick="balas_komen('<?php echo e(@erinfdl); ?>')" value="@erinfdl">Balas</button>
									</div>
								</div>
								<div class="row">
									<div class="comment-img col-sm-2" style="padding-right:0">
										<img src="<?php echo e(Session::get('foto')); ?>" class="img-responsive img-circle" style="width:32px;height:32px;border-radius: 50%;">
									</div>
									<div class="comment-text col-sm-10" style="padding-left:10px;">
										<strong style="font-size:16px;"><a href="">afraaknim</a></strong>
										<p style="margin-bottom:0;font-size:14px;color:#000;">Hello this is a test comment and this comment is particularly very long and it goes on and on and on.</p> 
										<span style="font-size:11px;color:gray;">on December 5th, 2016</span><button class="btn btn-link" style="font-size: 12px; font-weight: 500;" id="balas2" onclick="balas_komen('<?php echo e(@afraaknim); ?>')" value="@afraaknim">Balas</button>
									</div>
								</div>
								<div class="row">
									<div class="comment-img col-sm-2" style="padding-right:0">
										<img src="<?php echo e(Session::get('foto')); ?>" class="img-responsive img-circle" style="width:32px;height:32px;border-radius: 50%;">
									</div>
									<div class="comment-text col-sm-10" style="padding-left:10px;">
										<strong style="font-size:16px;"><a href="">rinezaspnl</a></strong>
										<p style="margin-bottom:0;font-size:14px;color:#000;">Hello this is a test comment and this comment is particularly very long and it goes on and on and on.</p> 
										<span style="font-size:11px;color:gray;">on December 5th, 2016</span><button class="btn btn-link" style="font-size: 12px; font-weight: 500;" id="balas3" onclick="balas_komen('<?php echo e(@rinezaspnl); ?>')" value="@rinezaspnl">Balas</button>
									</div>
								</div>
								<div class="row">
									<div class="comment-img col-sm-2" style="padding-right:0">
										<img src="<?php echo e(Session::get('foto')); ?>" class="img-responsive img-circle" style="width:32px;height:32px;border-radius: 50%;">
									</div>
									<div class="comment-text col-sm-10" style="padding-left:10px;">
										<strong style="font-size:16px;"><a href="">megacandra</a></strong>
										<p style="margin-bottom:0;font-size:14px;color:#000;">Hello this is a test comment and this comment is particularly very long and it goes on and on and on.</p> 
										<span style="font-size:11px;color:gray;">on December 5th, 2016</span><button class="btn btn-link" style="font-size: 12px; font-weight: 500;" id="balas4" onclick="balas_komen('<?php echo e(@megacandra); ?>')" value="@megacandra">Balas</button>
									</div>
								</div>
								<div class="row">
									<div class="comment-img col-sm-2" style="padding-right:0">
										<img src="<?php echo e(Session::get('foto')); ?>" class="img-responsive img-circle" style="width:32px;height:32px;border-radius: 50%;">
									</div>
									<div class="comment-text col-sm-10" style="padding-left:10px;">
										<strong style="font-size:16px;"><a href="">mderry</a></strong>
										<p style="margin-bottom:0;font-size:14px;color:#000;">Hello this is a test comment and this comment is particularly very long and it goes on and on and on.</p> 
										<span style="font-size:11px;color:gray;">on December 5th, 2016</span><button class="btn btn-link" style="font-size: 12px; font-weight: 500;" id="balas5" onclick="balas_komen('<?php echo e(@mderry); ?>')" value="@mderry">Balas</button>
									</div>
								</div>
							</ul>
							<div class="modal-meta-bottom"> <hr style="margin-top: 0.5rem;margin-bottom: 0.5rem;">
								<ul style="padding:0px;margin:0px;">
									<a class="modal-like" style="font-size:20px;padding-right:10px;" href="#"><i class="fa fa-heart-o"></i></a>
									<a class="modal-comment" style="font-size:20px;padding-right:10px;" href="#"><i class="fa fa-comment-o"></i></a>
									<a class="modal-share" style="font-size:20px;padding-right:10px;" href="#"><i class="fa fa-share-square-o"></i></a>
								</ul>
								<p style="font-size:14px;margin:0px;color:#000;">Like by afraaknim, erinfdl, and others</p>
								<span style="font-size:11px;color:gray">on December 5th, 2016</span>
								<hr style="margin-top: 0.5rem;margin-bottom: 0.5rem;">
								<ul style="padding:0px; margin-top:5px;">
									<span class="thumb-xs">
										<input class="form-control input-sm" type="text" id="kolom_balas" placeholder="Write your comment...">
									</span>
								</ul>		
							</div><!--/ modal-meta-bottom -->
						</div><!--/ modal-meta-top -->
					</div><!--/ col-md-4 -->
				</div><!--/ row -->
			</div><!--/ modal-body -->
		</div><!--/ modal-content -->
	</div><!--/ modal-dialog -->
</div>
<div class="modal fade" id="myModalMorePost" role="dialog">
    <div class="modal-dialog modal-sm" style="max-width: 400px;">
      	<div class="modal-content">
	        <div class="modal-content" style="text-align: center;">
	        <ul class="list-group list-group-flush">
	        	<li class="list-group-item"><a href="" style="font-weight: 600; color: red;"> Batal Mengikuti </a></li>
	        	<li class="list-group-item"><a href=""> Bagikan </a></li>
	        	<li class="list-group-item"><a href="" data-dismiss="modal"> Batalkan </a></li>
	        </ul>
      	</div>
      	</div>
    </div>
</div>

<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('Winku-Social-Network-Corporate-Responsive-Template/js/script.js')); ?>"></script>
<script type="text/javascript">
    function tampilkanDetilPost(idKonten) {
        $('#myModal').modal('show');
    }

    function balas_komen(balas) {
        // var uname = document.getElementById("balas").value;
        // var uname = document.getElementById("balas2").value;
        // var uname = document.getElementById("balas3").value;
        // var uname = document.getElementById("balas4").value;
        // var uname = document.getElementById("balas5").value;
        let html = '';
        html += '<input class="form-control input-sm" type="text" placeholder="Write your comment..." value="@'+balas+'">';
        $('.thumb-xs').html(html);
    }
</script>

</body>	

</html>